package com.iaroc.irobot.sample;

import com.iaroc.irobot.IRobotCreate;
import com.iaroc.irobot.util.TestReporter;
import com.sun.spot.util.Utils;
import com.sun.squawk.util.UnexpectedException;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/**
 * The startApp method of this class is called by the VM to start the
 * application.
 */
public class TestSerialInterfaceViaScriptMIDlet extends MIDlet {
    protected IRobotCreate create;
    protected TestReporter reporter;
    
    protected void doTest() {
        int successCount = 0;
        int ioExceptionCount = 0;
        int mismatchCount = 0;
        int waitTime = 100;
        label:
        while (true) {
            reporter.reportCounts(ioExceptionCount, successCount, mismatchCount);
            create.startRecordingScript();
            for (int i=0; i < 6; i++) {
                create.leds(true, true, true);
                create.waitTimeMilliseconds(waitTime);
                create.leds(false, false, false);
                create.waitTimeMilliseconds(waitTime);
            }
            waitTime += 100;
            if (waitTime > 300) {
                waitTime = 100;
            }
            try {
                int recordedCount = create.playScript();
                create.leds(true, true, true);
                Utils.sleep(2000);
                int[] recordedScript = create.getSerialConnection().getRecordedBytes();
                int[] returnedScript = create.showScript();
                if (recordedCount != returnedScript.length) {
                    mismatchCount++;
                    System.out.println("un-matched length");
                    for (int i=0; i < returnedScript.length; i++) {
                        System.out.println(i + "-" + returnedScript[i]);
                    }
                    continue label;
                }
                for (int i=0; i < recordedCount; i++) {
                    if (recordedScript[i] != returnedScript[i]) {
                        mismatchCount++;
                        System.out.println("un-matched data: sent, received");
                        for (int j=0; j < recordedCount; j++) {
                            System.out.println(j + "-" + recordedScript[j] + ":" + returnedScript[j] + (recordedScript[j] == returnedScript[j]?"":"<<<"));
                        }
                        continue label;
                    }
                }
                successCount++;
            } catch (UnexpectedException e) {
                ioExceptionCount++;
                e.printStackTrace();
            }
        }
    }

    protected void startApp() throws MIDletStateChangeException {
        // We use a reporter class in order to reduce the duplication of code for all of our tests
        reporter = new TestReporter();
        try {
            // Indicate we are about to initialize our connection to the Create
            reporter.reportInitializing(this.getClass().getName());
            create = new IRobotCreate();
            // Indicate we have not connected with the Create and are about to execute our test
            reporter.reportDoing();
            // Run the actual test code we want to do
            doTest();
            // Indicate we are done
            reporter.reportDone();
        } catch (Throwable e) {
            // Indicate we got an error
            reporter.reportError(e);
        }
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
    }
    
}
