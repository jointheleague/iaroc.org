package com.iaroc.irobot.sample;

import com.iaroc.irobot.IRobotCreate;
import com.iaroc.irobot.IRobotCreateConstants;

import com.iaroc.irobot.util.TestReporter;
import com.sun.spot.util.Utils;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/**
 * The startApp method of this class is called by the VM to start the
 * application.
 */
public class BumpsMIDlet extends MIDlet {
    protected IRobotCreate create;
    protected TestReporter reporter;
    
    protected void doTest() {
        create.leds(true, true, true);
        boolean playLed;
        boolean advanceLed;
        boolean powerLed;
        int runCount = 2;
        playLed = true;
        while (runCount > 0) {
            create.sensors(IRobotCreateConstants.SENSORS_BUMPS_AND_WHEEL_DROPS, null);
            advanceLed = powerLed = true;
            if (create.isBumpLeft() && create.isBumpRight()) {
                playLed = false;
            } else {
                if (!playLed) {
                    runCount--;
                    playLed = true;
                }
                if (create.isBumpLeft()) {
                    powerLed = false;
                } else if (create.isBumpRight()) {
                    advanceLed = false;
                }
            }
            create.leds(powerLed, playLed, advanceLed);
            Utils.sleep(250);
        }
    }

    protected void startApp() throws MIDletStateChangeException {
        // We use a reporter class in order to reduce the duplication of code for all of our tests
        reporter = new TestReporter();
        try {
            // Indicate we are about to initialize our connection to the Create
            reporter.reportInitializing(this.getClass().getName());
            create = new IRobotCreate();
            // Indicate we have not connected with the Create and are about to execute our test
            reporter.reportDoing();
            // Run the actual test code we want to do
            doTest();
            // Indicate we are done
            reporter.reportDone();
        } catch (Throwable e) {
            // Indicate we got an error
            reporter.reportError(e);
        }
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
    }
    
}
