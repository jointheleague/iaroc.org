package com.iaroc.irobot.util;

import com.iaroc.irobot.util.XLights;
import com.sun.spot.sensorboard.EDemoBoard;
import com.sun.spot.sensorboard.peripheral.ITriColorLED;
import com.sun.spot.sensorboard.peripheral.LEDColor;

public class TestReporter {
    protected XLights xLights;
    protected boolean reportedError;
    protected boolean isPsilonRunning;
    protected boolean debug;
    
    public TestReporter() {
        this(0, 7);
    }

    public TestReporter(int xLightsFirst, int xLightsLast) {
        xLights = new XLights(EDemoBoard.getInstance(), xLightsFirst, xLightsLast);
        setColor(LEDColor.WHITE);
    }

    public void report(String string) {
        System.out.println(string);
    }
    
    public void reportCounts(int redCount, int greenCount, int blueCount) {
        if (debug) {
            System.out.print("Reporting red: ");
            System.out.print(redCount);
            System.out.print(" green: ");
            System.out.print(greenCount);
            System.out.print(" blue: ");
            System.out.println(blueCount);
        }
        final int intensity = 63;
        xLights.stopPsilon();
        isPsilonRunning = false;
        ITriColorLED[] leds = EDemoBoard.getInstance().getLEDs();
        int mask = 1;
        for (int i=0; i < leds.length; i++) {
            int r = (redCount & mask) ==0 ?0:intensity;
            int g = (greenCount & mask) ==0 ?0:intensity;
            int b = (blueCount & mask) ==0 ?0:intensity;
//            System.out.println("setting LED" + i + "r=" + r + " g=" + g + " b=" + b);
            leds[i].setOn();
            leds[i].setRGB(r, g, b);
            mask *= 2;
        }
    }
    
    public void reportInitializing(String string) {
        System.out.print("Initializing: ");
        System.out.println(string);
        setColor(LEDColor.YELLOW);
    }

    public void reportDoing() {
        System.out.println("Doing");
        setColor(LEDColor.GREEN);
    }
    
    public void reportDone() {
        System.out.println("Done");
        if (reportedError) {
            return;
        }
        setColor(LEDColor.BLUE);
    }
    
    public void reportError(Throwable t) {
        System.out.println("Error");
        t.printStackTrace();
        setColor(LEDColor.RED);
        reportedError = true;
    }
    
    protected void setColor(LEDColor color) {
        xLights.setColor(color);
        if (!isPsilonRunning) {
            xLights.startPsilon();
            isPsilonRunning = true;
        }
    }
    
    public void setDebug(boolean debug) {
        this.debug = debug;
    }
    
}
