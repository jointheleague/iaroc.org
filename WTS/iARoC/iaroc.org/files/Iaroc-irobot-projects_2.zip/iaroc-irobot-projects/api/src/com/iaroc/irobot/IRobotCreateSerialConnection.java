package com.iaroc.irobot;


import java.io.IOException;

import com.sun.spot.sensorboard.EDemoBoard;
import com.sun.spot.sensorboard.io.IIOPin;
import com.sun.spot.util.BootloaderListener;
import com.sun.spot.util.Utils;
import com.sun.squawk.util.UnexpectedException;

public class IRobotCreateSerialConnection {
    protected EDemoBoard demoBoard;
    protected IIOPin baudRateSelectPin;
    protected boolean debug;
    protected int[] recordedBytes;
    protected int recordedBytesCount;
    protected boolean isRecording;

    public IRobotCreateSerialConnection(EDemoBoard demoBoard, IIOPin baudRateSelectPin) {
        this.demoBoard = demoBoard;
        this.baudRateSelectPin = baudRateSelectPin;
        new BootloaderListener().start();
        this.recordedBytes = new int[IRobotCreateConstants.MAX_COMMAND_SIZE];
        this.recordedBytesCount = 0;
        isRecording = false;
        while (true) {
            try {
                connectToCreate();
                break;
            } catch (UnexpectedException e) {
                System.out.println("Retrying connectToCreate");
            }
        }
    }

    protected void connectToCreate() {
        demoBoard.initUART(EDemoBoard.SERIAL_SPEED_19200, false);
        if (baudRateSelectPin != null) {
            if (debug) {
                System.out.println("Triggering baud rate select pin");
            }
            baudRateSelectPin.setAsOutput(true);
            baudRateSelectPin.setHigh();
// This is supposed to wake/turn on the Create but it does not seem to
/*
            baudRateSelectPin.setLow();
            Utils.sleep(100);
            baudRateSelectPin.setHigh();
            Utils.sleep(2000);
*/
            for (int i = 0; i < 3; i++) {
                baudRateSelectPin.setLow();
                Utils.sleep(250);
                baudRateSelectPin.setHigh();
                Utils.sleep(250);
            }
        }
        for (int i=0; i < IRobotCreateConstants.MAX_COMMAND_SIZE; i++) {
            sendByte(IRobotCreateConstants.COMMAND_START);
//            Utils.sleep(1);
        }
        sendByte(IRobotCreateConstants.COMMAND_RESET);
        Utils.sleep(4000);
        if (baudRateSelectPin != null) {
            if (debug) {
                System.out.println("Triggering baud rate select pin");
            }
            for (int i = 0; i < 3; i++) {
                baudRateSelectPin.setLow();
                Utils.sleep(250);
                baudRateSelectPin.setHigh();
                Utils.sleep(250);
            }
        }
        flushRead();
        sendByte(IRobotCreateConstants.COMMAND_START);
        while (true) {
            sendByte(IRobotCreateConstants.COMMAND_SENSORS);
            sendByte(IRobotCreateConstants.SENSORS_OI_MODE);
            int mode = readUnsignedByte();
            if (mode == IRobotCreateConstants.OI_MODE_PASSIVE) {
                break;
            }
        }
    }
    
    public void flushRead() {
        // Empty any data that might be in UART buffer
        int sleepCount = 4;
        while (sleepCount > 0) {
            try {
                demoBoard.receiveUART();
            } catch (IOException e) {
                Utils.sleep(40);
                sleepCount--;
            }
        }
    }

    public int[] getRecordedBytes() {
        return recordedBytes;
    }
    
    public int getRecordedBytesCount() {
        return recordedBytesCount;
    }
    
    public boolean isRecording() {
        return isRecording;
    }

    public int readSignedByte() {
        while (true) {
            try {
                int result = demoBoard.receiveUART();
                if (debug) {
                    System.out.print("read signed: ");
                    System.out.print(result);
                    System.out.print(':');
                    System.out.println((char) result);
                }
                return result;
            } catch (IOException e) {
                Utils.sleep(20);
            }
        }
    }

    public int readUnsignedByte() {
        if (debug) {
            System.out.println("read unsigned: ");
        }
        while (true) {
            try {
                int result = demoBoard.receiveUART() & 0xFF;
                if (debug) {
                    System.out.print("   ");
                    System.out.print(result);
                    System.out.print(':');
                    System.out.println((char) result);
                }
                return result;
            } catch (IOException e) {
                Utils.sleep(20);
                if (demoBoard.getSwitches()[EDemoBoard.SW1].isClosed()) {
                    throw new UnexpectedException("User pressed SW1 to get out of waiting for serial data", null);
                }
            }
        }
    }

    public int readSignedWord() {
        // Java is already twos complement, so no need for any translation
        int signed = ((readSignedByte() << 8) & 0xFFFFFF00) | readSignedByte();
        return signed;
    }
    
    public int readUnsignedBytes(int[] buffer, int start, int length) {
        if (debug) {
            System.out.print("read unsigned length: ");
            System.out.println(length);
        }
        for (int i=0; i < length; i++) {
            if (debug) {
                System.out.print("   read[");
                System.out.print(i);
                System.out.print("]:");
            }
            while (true) {
                try {
                    buffer[start + i] = demoBoard.receiveUART() & 0xFF;
                    if (debug) {
                        System.out.print("   ");
                        System.out.println(buffer[start]);
                    }
                    break;
                } catch (IOException e) {
                    Utils.sleep(20);
                }
            }
        }
        return length;
    }

    public int readUnsignedWord() {
        int unsigned = (readUnsignedByte() << 8) | readUnsignedByte();
        return unsigned;
    }
    
    public void sendByte(int b) {
        if (isRecording) {
            recordedBytes[recordedBytesCount++] = b;
        } else {
            if (debug) {
                System.out.print("sending: ");
                System.out.println(b);
            }
            demoBoard.sendUART((byte) b);
            Utils.sleep(1);
        }
    }
    
    public void sendBytes(int[] bytes, int start, int length) {
        if (isRecording) {
            for (; length > 0; start++, length--) {
                recordedBytes[recordedBytesCount++] = bytes[start];
            }
        } else {
            if (debug) {
                System.out.print("sending length: ");
                System.out.println(length);
            }
            for (int i=0; i < length; i++) {
                if (start % 8 == 0) {
                    Utils.sleep(20);
                }
                if (debug) {
                    System.out.print("   sending[");
                    System.out.print(i);
                    System.out.print("]: ");
                    System.out.println(bytes[start + i]);
                }
                demoBoard.sendUART((byte) bytes[start + i]);
                Utils.sleep(1);
            }
        }
    }
    

    public void sendSignedWord(int value) {
        // Java bit representation is already two's complement
        sendByte(value >> 8);
        sendByte(value & 0xFF);
    }
    
    public void sendUnsignedWord(int value) {
        sendByte(value >> 8);
        sendByte(value & 0xFF);
    }
    
    public void afterCommandPause() {
        if(isRecording) {
            return;
        }
        if (debug) {
            System.out.println("afterCommandPause");
        }
        Utils.sleep(IRobotCreateConstants.AFTER_COMMAND_PAUSE_TIME);
    }

    public void setDebug(boolean debug) {
        this.debug = debug;
    }

    public void startRecording() {
        isRecording = true;
    }
    
    public int stopRecording() {
        isRecording = false;
        int count = recordedBytesCount;
        recordedBytesCount = 0;
        return count;
    }
    
}
