package com.iaroc.irobot;

import com.iaroc.irobot.util.XLights;
import com.sun.spot.sensorboard.EDemoBoard;
import com.sun.spot.sensorboard.peripheral.LEDColor;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/**
 * The startApp method of this class is called by the VM to start the
 * application.
 */
public class TemplateMIDlet extends MIDlet {

    protected void startApp() throws MIDletStateChangeException {
        XLights lights = new XLights(EDemoBoard.getInstance(), 0, 7);
        try {
            lights.setColor(LEDColor.YELLOW);
            lights.startPsilon();
            IRobotCreate create = new IRobotCreate();
            lights.setColor(LEDColor.GREEN);
            create.setVelocity(100);
            create.goForward();
            create.waitTimeMilliseconds(500);
            create.stop();
            lights.setColor(LEDColor.BLUE);
        } catch (Throwable e) {
            lights.setColor(LEDColor.RED);
            e.printStackTrace();
        }
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
    }
    
}
