package com.iaroc.irobot.sample;

import com.iaroc.irobot.IRobotCreate;

import com.iaroc.irobot.util.XLights;
import com.sun.spot.sensorboard.EDemoBoard;
import com.sun.spot.sensorboard.peripheral.LEDColor;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/**
 * The startApp method of this class is called by the VM to start the
 * application.
 */
public class MakeSquareMIDlet extends MIDlet {
    protected IRobotCreate create;
    protected XLights xLights;
    
    protected void doTest() {
        int velocity = 100;
        create.setVelocity(velocity);
        for (int i=0; i < 4; i++) {
            create.goForward();
            create.waitDistance(150);
            create.spinRight();
            create.waitAngle(90);
        }
        create.stop();
    }

    protected void startApp() throws MIDletStateChangeException {
        xLights = new XLights(EDemoBoard.getInstance(), 0, 7);
        xLights.setColor(LEDColor.WHITE);
        xLights.startPsilon();
        System.out.print("Initializing: ");
        System.out.println(this.getClass().getName());
        xLights.setColor(LEDColor.YELLOW);
        try {
            create = new IRobotCreate();
            // Indicate we have not connected with the Create and are about to execute our test
            xLights.setColor(LEDColor.GREEN);
            // Run the actual test code we want to do
            doTest();
            // Indicate we are done
            xLights.setColor(LEDColor.BLUE);
        } catch (Throwable e) {
            e.printStackTrace();
            // Indicate we got an error
            xLights.setColor(LEDColor.RED);
        }
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
    }
    
}
