package com.iaroc.irobot.sample;

public class OnLeftCliffSensorState extends State {

    public OnLeftCliffSensorState(StateMachine machine) {
        super(machine);
    }

    public void cliffFrontLeftSignalEvent(int oldInt, int cliffFrontLeftSignal) {
        super.cliffFrontLeftSignalEvent(oldInt, cliffFrontLeftSignal);
        if (isOnLeft) {
            getCreate().spinLeft();
        } else {
            getCreate().goForward();
            getStateMachine().enterState(getStateMachine().getGoingForwardState());
        }
    }

}
