package com.iaroc.irobot.sample;

import com.iaroc.irobot.IRobotCreate;
import com.iaroc.irobot.IRobotCreateConstants;
import com.sun.spot.sensorboard.EDemoBoard;
import com.sun.spot.sensorboard.peripheral.ITriColorLED;

public class StateMachine {
    public static final int CLIFF_SIGNAL_WHITE_BLACK_DELTA = 500;

    protected IRobotCreate create;
    protected EDemoBoard demoBoard;
    protected State currentState;
    protected FindLineState findLineState;
    protected OnLeftCliffSensorState onLeftCliffSensorState;
    protected OnRightCliffSensorState onRightCliffSensorState;
    protected GoingForwardState goingForwardState;
    protected int notWhiteSignalValue;
    protected boolean keepGoing;
    protected boolean debug;
    protected ITriColorLED leftLed;
    protected ITriColorLED rightLed;
    
    public StateMachine(IRobotCreate robot, EDemoBoard demoBoard) {
        create = robot;
        this.demoBoard = demoBoard;
        leftLed = demoBoard.getLEDs()[0];
        rightLed = demoBoard.getLEDs()[7];
        findLineState = new FindLineState(this);
        goingForwardState = new GoingForwardState(this);
        onLeftCliffSensorState = new OnLeftCliffSensorState(this);
        onRightCliffSensorState = new OnRightCliffSensorState(this);
    }
    
    public void enterState(State state) {
        if (currentState == state) {
            return;
        }
        if (currentState != null) {
            currentState.exit();
        }
        currentState = state;
        currentState.enter();
    }
    
    public IRobotCreate getCreate() {
        return create;
    }

    public State getCurrentState() {
        return currentState;
    }
    
    public FindLineState getFindLineState() {
        return findLineState;
    }
    
    public GoingForwardState getGoingForwardState() {
        return goingForwardState;
    }

    public int getNotWhiteSignalValue() {
        return notWhiteSignalValue;
    }
    
    public OnLeftCliffSensorState getOnLeftCliffSensorState() {
        return onLeftCliffSensorState;
    }
    
    public OnRightCliffSensorState getOnRightCliffSensorState() {
        return onRightCliffSensorState;
    }

    public boolean isCliffSignalOnLine(int signal, boolean isLeft) {
        boolean isOnLine = Math.abs(notWhiteSignalValue - signal) > CLIFF_SIGNAL_WHITE_BLACK_DELTA;
        ITriColorLED led = isLeft?leftLed:rightLed;
        led.setRGB(0, 255, 0);
        led.setOn(isOnLine);
        return isOnLine;
    }

    public boolean keepGoing() {
        return keepGoing;
    }
    
    public void pollSensors() {
        getCreate().sensors(IRobotCreateConstants.SENSORS_GROUP_ID6, getCurrentState());
    }

    public void setDebug(boolean debug) {
        this.debug = debug;
    }
    
    public void setKeepGoing(boolean keepGoing) {
        this.keepGoing = keepGoing;
    }
    
    public void setNotWhiteSignalValue(int value) {
        notWhiteSignalValue = value;
    }
    
    public void start() {
        create.setCliffSignalHysteresis(50);
        create.setVelocity(50);
        getCreate().sensors(IRobotCreateConstants.SENSORS_CLIFF_FRONT_LEFT_SIGNAL);
        int signal = getCreate().getCliffFrontLeftSignal();
        setNotWhiteSignalValue(signal);
        keepGoing = true;
        getCreate().spinRight();
        enterState(getFindLineState());
    }

}
