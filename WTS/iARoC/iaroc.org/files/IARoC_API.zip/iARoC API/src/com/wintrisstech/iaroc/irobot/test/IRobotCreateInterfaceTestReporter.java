package com.wintrisstech.iaroc.irobot.test;

public class IRobotCreateInterfaceTestReporter {

    public void report(String string) {
        System.out.println(string);
    }
    
    public void reportCounts(int successCount, int ioExceptionCount, int mismatchCount) {
        System.out.println("Reporting");
        System.out.print("   Successes: ");
        System.out.println(successCount);
        System.out.print("   I/O errors: ");
        System.out.println(ioExceptionCount);
        System.out.print("   Mismatches: ");
        System.out.println(mismatchCount);
    }
    
    public void reportInitializing() {
        System.out.println("Initializing");
    }

    public void reportDoing() {
        System.out.println("Doing");
    }
    
    public void reportDone() {
        System.out.println("Done");
    }
    
    public void reportError() {
        System.out.println("Error");
    }
    

}
