package com.wintrisstech.iaroc.irobot.test;

import com.sun.spot.util.Utils;
import com.sun.squawk.util.UnexpectedException;
import com.wintrisstech.iaroc.irobot.IRobotCreateConstants;
import com.wintrisstech.iaroc.irobot.IRobotCreateInterface;
import com.wintrisstech.iaroc.irobot.IRobotCreateEventHandler;

public class IRobotCreateInterfaceTest {

    public static void testBlinkLeds(IRobotCreateInterface create, IRobotCreateInterfaceTestReporter reporter) {
        reporter.report("testBlinkLeds");
        try {
            for (int i=0; i < 1; i++) {
                create.leds(true, true, true);
                create.getSerialConnection().sleep(250);
                create.leds(false, false, false);
                create.getSerialConnection().sleep(250);
            }
        } catch (Throwable e) {
            reporter.reportError();
            e.printStackTrace();
        }
    }
    
    public static void testBumps(IRobotCreateInterface create, IRobotCreateInterfaceTestReporter reporter) {
        reporter.report("testMakeSquare");
        create.leds(true, true, true);
        boolean playLed;
        boolean advanceLed;
        boolean powerLed;
        int runCount = 2;
        playLed = true;
        while (runCount > 0) {
            try {
                create.sensors(IRobotCreateConstants.SENSORS_BUMPS_AND_WHEEL_DROPS, null);
                advanceLed = powerLed = true;
                if (create.isBumpLeft() && create.isBumpRight()) {
                    playLed = false;
                } else {
                    if (!playLed) {
                        runCount--;
                        playLed = true;
                    }
                    if (create.isBumpLeft()) {
                        powerLed = false;
                    } else if (create.isBumpRight()) {
                        advanceLed = false;
                    }
                }
                create.leds(powerLed, playLed, advanceLed);
            } catch (IllegalStateException e) {
                reporter.reportError();
                e.printStackTrace();
            }
            create.getSerialConnection().sleep(250);
        }
    }
    
    public static void testDrive(final IRobotCreateInterface create, final IRobotCreateInterfaceTestReporter reporter) {
        reporter.report("testDrive");
        final int maxVelocity = 100;
        final boolean[] doneFlagHolder = new boolean[1];
        
        IRobotCreateEventHandler eventHandler = new IRobotCreateEventHandler() {
            int rightVelocity = 100;
            int leftVelocity = 100;
            
            public void bumpLeftEvent(boolean oldBoolean, boolean bumpLeft) {
                super.bumpLeftEvent(oldBoolean, bumpLeft);
                if (bumpLeft) {
                    rightVelocity = -maxVelocity;
                    leftVelocity = maxVelocity;
                } else {
                    rightVelocity = maxVelocity;
                    leftVelocity = maxVelocity;
                }
                try {
                    create.driveDirect(rightVelocity, leftVelocity);
                } catch (Throwable e) {
                    reporter.reportError();
                    e.printStackTrace();
                }
            }
            
            public void bumpRightEvent(boolean oldBoolean, boolean bumpRight) {
                super.bumpRightEvent(oldBoolean, bumpRight);
                if (bumpRight) {
                    rightVelocity = maxVelocity;
                    leftVelocity = -maxVelocity;
                } else {
                    rightVelocity = maxVelocity;
                    leftVelocity = maxVelocity;
                }
                try {
                    create.driveDirect(rightVelocity, leftVelocity);
                } catch (Throwable e) {
                    reporter.reportError();
                    e.printStackTrace();
                }
            }
            
            public void playButtonEvent(boolean oldBoolean, boolean playButton) {
                super.playButtonEvent(oldBoolean, playButton);
                doneFlagHolder[0] = true;
                try {
                    create.driveDirect(0, 0);
                } catch (Throwable e) {
                    reporter.reportError();
                    e.printStackTrace();
                }
            }
        };
        
        try {
            create.driveDirect(maxVelocity, maxVelocity);
            while (!doneFlagHolder[0]) {
                create.sensors(IRobotCreateConstants.SENSORS_GROUP_ID6, eventHandler);
                Utils.sleep(50);
            }
            create.drive(0, 0);
        } catch (Throwable e) {
            reporter.reportError();
            e.printStackTrace();
        }
    }

    public static void testMakeSquare(IRobotCreateInterface create, IRobotCreateInterfaceTestReporter reporter) {
        reporter.report("testMakeSquare");
        try {
            create.startRecordingScript();
            int velocity = 100;
            for (int i=0; i < 4; i++) {
                create.drive(velocity, IRobotCreateConstants.DRIVE_STRAIGHT);
                create.waitDistance(150);
                create.drive(velocity, IRobotCreateConstants.DRIVE_TURN_IN_PLACE_CLOCKWISE);
                create.waitAngle(-90);
            }
            create.drive(0, 0);
            create.playScript();
        } catch (Throwable e) {
            reporter.reportError();
            e.printStackTrace();
        }
    }
    
    public static void testSensors(IRobotCreateInterface create, IRobotCreateInterfaceTestReporter reporter) {
        reporter.report("testSensors");
        IRobotCreateEventHandler eventHandler = new IRobotCreateEventHandler();
        eventHandler.setDebug(true);
        create.setWallSignalHysteresis(2);
        create.setCliffSignalHysteresis(300);
        while (true) {
            create.sensors(IRobotCreateConstants.SENSORS_GROUP_ID6, eventHandler);
            Utils.sleep(50);
        }
    }
    
    public static void testSerialInterfaceViaScript(IRobotCreateInterface create, IRobotCreateInterfaceTestReporter reporter) {
        reporter.report("testSerialInterfaceViaScript");
        int successCount = 0;
        int ioExceptionCount = 0;
        int mismatchCount = 0;
        int waitTime = 100;
        label:
        while (true) {
            reporter.reportCounts(successCount, ioExceptionCount, mismatchCount);
            create.startRecordingScript();
            for (int i=0; i < 6; i++) {
                create.leds(true, true, true);
                create.waitTimeMilliseconds(waitTime);
                create.leds(false, false, false);
                create.waitTimeMilliseconds(waitTime);
            }
            waitTime += 100;
            if (waitTime > 300) {
                waitTime = 100;
            }
            try {
                int recordedCount = create.playScript();
                create.leds(true, true, true);
                create.getSerialConnection().sleep(2000);
                int[] recordedScript = create.getSerialConnection().getRecordedBytes();
                int[] returnedScript = create.showScript();
                if (recordedCount != returnedScript.length) {
                    mismatchCount++;
                    System.out.println("un-matched length");
                    for (int i=0; i < returnedScript.length; i++) {
                        System.out.println(i + "-" + returnedScript[i]);
                    }
                    continue label;
                }
                for (int i=0; i < recordedCount; i++) {
                    if (recordedScript[i] != returnedScript[i]) {
                        mismatchCount++;
                        System.out.println("un-matched data: sent, received");
                        for (int j=0; j < recordedCount; j++) {
                            System.out.println(j + "-" + recordedScript[j] + ":" + returnedScript[j] + (recordedScript[j] == returnedScript[j]?"":"<<<"));
                        }
                        continue label;
                    }
                }
                successCount++;
            } catch (UnexpectedException e) {
                ioExceptionCount++;
                e.printStackTrace();
            }
        }
    }

}
