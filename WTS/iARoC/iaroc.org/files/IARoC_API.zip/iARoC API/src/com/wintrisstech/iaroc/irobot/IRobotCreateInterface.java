package com.wintrisstech.iaroc.irobot;

import java.io.IOException;

public class IRobotCreateInterface {
    protected static final int NUMBER_OF_SENSORS = 48;
    protected static final int SENSORID_advanceButton = 0;
    protected static final int SENSORID_angle = 25;
    protected static final int SENSORID_batteryCapacity = 1;
    protected static final int SENSORID_batteryCharge = 2;
    protected static final int SENSORID_batteryTemperature = 3;
    protected static final int SENSORID_bumpLeft = 4;
    protected static final int SENSORID_bumpRight = 5;
    protected static final int SENSORID_cargoBayAnalogSignal = 6;
    protected static final int SENSORID_cargoBayDeviceDetectBaudRateChange = 11;
    protected static final int SENSORID_cargoBayDigitalInput0 = 7;
    protected static final int SENSORID_cargoBayDigitalInput1 = 8;
    protected static final int SENSORID_cargoBayDigitalInput2 = 9;
    protected static final int SENSORID_cargoBayDigitalInput3 = 10;
    protected static final int SENSORID_chargingState = 12;
    protected static final int SENSORID_cliffFrontLeft = 16;
    protected static final int SENSORID_cliffFrontLeftSignal = 13;
    protected static final int SENSORID_cliffFrontRight = 17;
    protected static final int SENSORID_cliffFrontRightSignal = 14;
    protected static final int SENSORID_cliffLeft = 18;
    protected static final int SENSORID_cliffLeftSignal = 19;
    protected static final int SENSORID_cliffRight = 20;
    protected static final int SENSORID_cliffRightSignal = 15;
    protected static final int SENSORID_current = 21;
    protected static final int SENSORID_distance = 26;
    protected static final int SENSORID_homeBaseChargerAvailable = 22;
    protected static final int SENSORID_infraredByte = 23;
    protected static final int SENSORID_internalChargerAvailable = 24;
    protected static final int SENSORID_leftWheelOvercurrent = 30;
    protected static final int SENSORID_lowSideDriver0Overcurrent = 27;
    protected static final int SENSORID_lowSideDriver1Overcurrent = 28;
    protected static final int SENSORID_lowSideDriver2Overcurrent = 29;
    protected static final int SENSORID_numberOfStreamPackets = 31;
    protected static final int SENSORID_oiMode = 32;
    protected static final int SENSORID_playButton = 33;
    protected static final int SENSORID_requestedLeftVelocity = 34;
    protected static final int SENSORID_requestedRadius = 35;
    protected static final int SENSORID_requestedRightVelocity = 36;
    protected static final int SENSORID_requestedVelocity = 37;
    protected static final int SENSORID_rightWheelOvercurrent = 38;
    protected static final int SENSORID_songNumber = 39;
    protected static final int SENSORID_songPlaying = 40;
    protected static final int SENSORID_virtualWall = 41;
    protected static final int SENSORID_voltage = 42;
    protected static final int SENSORID_wall = 43;
    protected static final int SENSORID_wallSignal = 44;
    protected static final int SENSORID_wheelDropCaster = 45;
    protected static final int SENSORID_wheelDropLeft = 46;
    protected static final int SENSORID_wheelDropRight = 47;

    protected int accumulatedAngle;
    protected int accumulatedDistance;
    protected int cliffSignalHysteresis;
    protected int[] sensorOldValues;
    protected boolean[] sensorUpdatedFlags;
    protected int[] sensorValues;
    protected IRobotCreateSerialConnection serialConnection;
    protected int velocity;
    protected int wallSignalHysteresis;

    public IRobotCreateInterface(IRobotCreateSerialConnection serialConnection) {
        this.serialConnection = serialConnection;
        full();
        sensorValues = new int[NUMBER_OF_SENSORS];
        sensorUpdatedFlags = new boolean[NUMBER_OF_SENSORS];
        wallSignalHysteresis = 2;
        cliffSignalHysteresis = 50;
        velocity = IRobotCreateConstants.DRIVE_MAX_VELOCITY / 2;
        // Some initialization to make it such that we minimize the events that will be fired
        // when we first connect to the Create
        sensorValues[SENSORID_infraredByte] = IRobotCreateConstants.INFRARED_BYTE_NONE;
        leds(true, true, true);
    }

    public void cover() {
        if (IRobotCreateConstants.DEBUG) {
            System.out.println("cover");
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_DEMO_COVER);
        serialConnection.afterCommandPause();
    }
    
    public void coverAndDock() {
        if (IRobotCreateConstants.DEBUG) {
            System.out.println("coverAndDock");
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_DEMO_COVER_AND_DOCK);
        serialConnection.afterCommandPause();
    }
    
    public void demo(int demoType) {
        if (IRobotCreateConstants.DEBUG) {
            System.out.print("demo: ");
            System.out.println(demoType);
        }
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_DEMO);
        serialConnection.sendByte(demoType);
        serialConnection.afterCommandPause();
    }

    public void digitalOutputs(boolean pin0High, boolean pin1High, boolean pin2High) {
        if (IRobotCreateConstants.DEBUG) {
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_DIGITAL_OUTPUTS);
        serialConnection.sendByte((pin0High ? IRobotCreateConstants.DIGITAL_OUTPUT_PIN0:0) | (pin1High ? IRobotCreateConstants.DIGITAL_OUTPUT_PIN1:0) | (pin2High ? IRobotCreateConstants.DIGITAL_OUTPUT_PIN2:0));
        serialConnection.afterCommandPause();
    }
    
    protected void dispatchEvent(int sensorId, int oldValue, int newValue, IRobotCreateEventHandler eventHandler) {
        if (eventHandler == null) {
            return;
        }
        switch (sensorId) {
        case SENSORID_advanceButton:
            eventHandler.advanceButtonEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_batteryCapacity:
            eventHandler.batteryCapacityEvent(sensorValues[SENSORID_batteryCapacity], sensorValues[SENSORID_batteryCapacity]);
            break;
        case SENSORID_batteryCharge:
            eventHandler.batteryChargeEvent(sensorValues[SENSORID_batteryCharge], sensorValues[SENSORID_batteryCharge]);
            break;
        case SENSORID_batteryTemperature:
            eventHandler.batteryTemperatureEvent(sensorValues[SENSORID_batteryTemperature], sensorValues[SENSORID_batteryTemperature]);
            break;
        case SENSORID_bumpLeft:
            eventHandler.bumpLeftEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_bumpRight:
            eventHandler.bumpRightEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_cargoBayAnalogSignal:
            eventHandler.cargoBayAnalogSignalEvent(sensorValues[SENSORID_cargoBayAnalogSignal], sensorValues[SENSORID_cargoBayAnalogSignal]);
            break;
        case SENSORID_cargoBayDigitalInput0:
            eventHandler.cargoBayDigitalInput0Event(oldValue != 0, newValue != 0);
            break;
        case SENSORID_cargoBayDigitalInput1:
            eventHandler.cargoBayDigitalInput1Event(oldValue != 0, newValue != 0);
            break;
        case SENSORID_cargoBayDigitalInput2:
            eventHandler.cargoBayDigitalInput2Event(oldValue != 0, newValue != 0);
            break;
        case SENSORID_cargoBayDigitalInput3:
            eventHandler.cargoBayDigitalInput3Event(oldValue != 0, newValue != 0);
            break;
        case SENSORID_cargoBayDeviceDetectBaudRateChange:
            eventHandler.cargoBayDeviceDetectBaudRateChangeEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_chargingState:
            eventHandler.chargingStateEvent(sensorValues[SENSORID_chargingState], sensorValues[SENSORID_chargingState]);
            break;
        case SENSORID_cliffFrontLeftSignal:
            eventHandler.cliffFrontLeftSignalEvent(sensorValues[SENSORID_cliffFrontLeftSignal], sensorValues[SENSORID_cliffFrontLeftSignal]);
            break;
        case SENSORID_cliffFrontRightSignal:
            eventHandler.cliffFrontRightSignalEvent(sensorValues[SENSORID_cliffFrontRightSignal], sensorValues[SENSORID_cliffFrontRightSignal]);
            break;
        case SENSORID_cliffRightSignal:
            eventHandler.cliffRightSignalEvent(sensorValues[SENSORID_cliffRightSignal], sensorValues[SENSORID_cliffRightSignal]);
            break;
        case SENSORID_cliffFrontLeft:
            eventHandler.cliffFrontLeftEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_cliffFrontRight:
            eventHandler.cliffFrontRightEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_cliffLeft:
            eventHandler.cliffLeftEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_cliffLeftSignal:
            eventHandler.cliffLeftSignalEvent(sensorValues[SENSORID_cliffLeftSignal], sensorValues[SENSORID_cliffLeftSignal]);
            break;
        case SENSORID_cliffRight:
            eventHandler.cliffRightEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_current:
            eventHandler.currentEvent(sensorValues[SENSORID_current], sensorValues[SENSORID_current]);
            break;
        case SENSORID_homeBaseChargerAvailable:
            eventHandler.homeBaseChargerAvailableEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_infraredByte:
            eventHandler.infraredByteEvent(sensorValues[SENSORID_infraredByte], sensorValues[SENSORID_infraredByte]);
            break;
        case SENSORID_internalChargerAvailable:
            eventHandler.internalChargerAvailableEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_angle:
            eventHandler.angleEvent(sensorValues[SENSORID_angle], sensorValues[SENSORID_angle]);
            break;
        case SENSORID_distance:
            eventHandler.distanceEvent(sensorValues[SENSORID_distance], sensorValues[SENSORID_distance]);
            break;
        case SENSORID_lowSideDriver0Overcurrent:
            eventHandler.lowSideDriver0OvercurrentEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_lowSideDriver1Overcurrent:
            eventHandler.lowSideDriver1OvercurrentEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_lowSideDriver2Overcurrent:
            eventHandler.lowSideDriver2OvercurrentEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_leftWheelOvercurrent:
            eventHandler.leftWheelOvercurrentEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_numberOfStreamPackets:
            eventHandler.numberOfStreamPacketsEvent(sensorValues[SENSORID_numberOfStreamPackets], sensorValues[SENSORID_numberOfStreamPackets]);
            break;
        case SENSORID_oiMode:
            eventHandler.oiModeEvent(sensorValues[SENSORID_oiMode], sensorValues[SENSORID_oiMode]);
            break;
        case SENSORID_playButton:
            eventHandler.playButtonEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_requestedLeftVelocity:
            eventHandler.requestedLeftVelocityEvent(sensorValues[SENSORID_requestedLeftVelocity], sensorValues[SENSORID_requestedLeftVelocity]);
            break;
        case SENSORID_requestedRadius:
            eventHandler.requestedRadiusEvent(sensorValues[SENSORID_requestedRadius], sensorValues[SENSORID_requestedRadius]);
            break;
        case SENSORID_requestedRightVelocity:
            eventHandler.requestedRightVelocityEvent(sensorValues[SENSORID_requestedRightVelocity], sensorValues[SENSORID_requestedRightVelocity]);
            break;
        case SENSORID_requestedVelocity:
            eventHandler.requestedVelocityEvent(sensorValues[SENSORID_requestedVelocity], sensorValues[SENSORID_requestedVelocity]);
            break;
        case SENSORID_rightWheelOvercurrent:
            eventHandler.rightWheelOvercurrentEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_songNumber:
            eventHandler.songNumberEvent(sensorValues[SENSORID_songNumber], sensorValues[SENSORID_songNumber]);
            break;
        case SENSORID_songPlaying:
            eventHandler.songPlayingEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_virtualWall:
            eventHandler.virtualWallEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_voltage:
            eventHandler.voltageEvent(sensorValues[SENSORID_voltage], sensorValues[SENSORID_voltage]);
            break;
        case SENSORID_wall:
            eventHandler.wallEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_wallSignal:
            eventHandler.wallSignalEvent(sensorValues[SENSORID_wallSignal], sensorValues[SENSORID_wallSignal]);
            break;
        case SENSORID_wheelDropCaster:
            eventHandler.wheelDropCasterEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_wheelDropLeft:
            eventHandler.wheelDropLeftEvent(oldValue != 0, newValue != 0);
            break;
        case SENSORID_wheelDropRight:
            eventHandler.wheelDropRightEvent(oldValue != 0, newValue != 0);
            break;
        default:
            throw new IllegalArgumentException(String.valueOf(sensorId));
        }
    }

    public void drive(int velocity, int radius) {
        if (IRobotCreateConstants.DEBUG) {
            System.out.print("drive velocity: ");
            System.out.print(velocity);
            System.out.print(" radius: ");
            System.out.println(radius);
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_DRIVE);
        serialConnection.sendSignedWord(velocity);
        serialConnection.sendSignedWord(radius);
        serialConnection.afterCommandPause();
    }
    
    public void driveDirect(int rightVelocity, int leftVelocity) {
        if (IRobotCreateConstants.DEBUG) {
            System.out.print("driveDirect: ");
            System.out.print(rightVelocity);
            System.out.print(" leftVelocity: ");
            System.out.println(leftVelocity);
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_DRIVE_DIRECT);
        serialConnection.sendSignedWord(rightVelocity);
        serialConnection.sendSignedWord(leftVelocity);
        serialConnection.afterCommandPause();
    }
    
    public void full() {
        if (IRobotCreateConstants.DEBUG) {
            System.out.println("full");
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_MODE_FULL);
        serialConnection.afterCommandPause();
    }

    public int getAccumulatedAngle() {
        return accumulatedAngle;
    }

    public int getAccumulatedDistance() {
        return accumulatedDistance;
    }

    public int getAngle() {
        return getSensorInteger(SENSORID_angle);
    }

    public int getBatteryCapacity() {
        return getSensorInteger(SENSORID_batteryCapacity);
    }

    public int getBatteryCharge() {
        return getSensorInteger(SENSORID_batteryCharge);
    }
    
    public int getBatteryTemperature() {
        return getSensorInteger(SENSORID_batteryTemperature);
    }
    
    public int getCargoBayAnalogSignal() {
        return getSensorInteger(SENSORID_cargoBayAnalogSignal);
    }
    
    public int getChargingState() {
        return getSensorInteger(SENSORID_chargingState);
    }
    
    public int getCliffFrontLeftSignal() {
        return getSensorInteger(SENSORID_cliffFrontLeftSignal);
    }
    
    public int getCliffFrontRightSignal() {
        return getSensorInteger(SENSORID_cliffFrontRightSignal);
    }
    
    public int getCliffLeftSignal() {
        return getSensorInteger(SENSORID_cliffLeftSignal);
    }
    
    public int getCliffRightSignal() {
        return getSensorInteger(SENSORID_cliffRightSignal);
    }

    public int getCliffSignalHysteris() {
        return cliffSignalHysteresis;
    }
    
    public int getCurrent() {
        return getSensorInteger(SENSORID_current);
    }

    public int getDistance() {
        return getSensorInteger(SENSORID_distance);
    }
    
    public int getInfraredByte() {
        return getSensorInteger(SENSORID_infraredByte);
    }

    public int getNumberOfStreamPackets() {
        return getSensorInteger(SENSORID_numberOfStreamPackets);
    }

    public int getOiMode() {
        return getSensorInteger(SENSORID_oiMode);
    }

    public int getRequestedLeftVelocity() {
        return getSensorInteger(SENSORID_requestedLeftVelocity);
    }

    public int getRequestedRadius() {
        return getSensorInteger(SENSORID_requestedRadius);
    }

    public int getRequestedRightVelocity() {
        return getSensorInteger(SENSORID_requestedRightVelocity);
    }

    public int getRequestedVelocity() {
        return getSensorInteger(SENSORID_requestedVelocity);
    }

    protected boolean getSensorBoolean(int sensorId) {
        if (!sensorUpdatedFlags[sensorId]) {
            throw new IllegalStateException("Dont know the state of the sensor requested");
        }
        return sensorValues[sensorId] != 0;
    };
    
    protected int getSensorInteger(int sensorId) {
        if (!sensorUpdatedFlags[sensorId]) {
            throw new IllegalStateException("Dont know the state of the sensor requested");
        }
        return sensorValues[sensorId];
    };

    
    public IRobotCreateSerialConnection getSerialConnection() {
        return serialConnection;
    };

    public int getSongNumber() {
        return getSensorInteger(SENSORID_songNumber);
    };

    
    public int getVoltage() {
        return getSensorInteger(SENSORID_voltage);
    };

    
    public int getWallSignal() {
        return getSensorInteger(SENSORID_wallSignal);
    };

    
    public int getWallSignalHysteris() {
        return wallSignalHysteresis;
    };

    
    public void goBackward() throws IOException {
        drive(-velocity, IRobotCreateConstants.DRIVE_STRAIGHT);
    };

    
    public void goForward() throws IOException {
        drive(velocity, IRobotCreateConstants.DRIVE_STRAIGHT);
    };

    
    public boolean isAdvanceButtonDown() {
        return getSensorBoolean(SENSORID_advanceButton);
    };

    
    public boolean isBumpLeft() {
        return getSensorBoolean(SENSORID_bumpLeft);
    };

    
    public boolean isBumpRight() {
        return getSensorBoolean(SENSORID_bumpRight);
    };

    
    public boolean isCargoBayDeviceDetectBaudRateChangeHigh() {
        return getSensorBoolean(SENSORID_cargoBayDeviceDetectBaudRateChange);
    };

    
    public boolean isCargoBayDigitalInput0High() {
        return getSensorBoolean(SENSORID_cargoBayDigitalInput0);
    };

    
    public boolean isCargoBayDigitalInput1High() {
        return getSensorBoolean(SENSORID_cargoBayDigitalInput1);
    };

    
    public boolean isCargoBayDigitalInput2High() {
        return getSensorBoolean(SENSORID_cargoBayDigitalInput2);
    };

    
    public boolean isCargoBayDigitalInput3High() {
        return getSensorBoolean(SENSORID_cargoBayDigitalInput3);
    };

    
    public boolean isCliffFrontLeft() {
        return getSensorBoolean(SENSORID_cliffFrontLeft);
    };

    
    public boolean isCliffFrontRight() {
        return getSensorBoolean(SENSORID_cliffFrontRight);
    };

    
    public boolean isCliffLeft() {
        return getSensorBoolean(SENSORID_cliffLeft);
    };

    
    public boolean isCliffRight() {
        return getSensorBoolean(SENSORID_cliffRight);
    };

    
    public boolean isHomeBaseChargerAvailable() {
        return getSensorBoolean(SENSORID_homeBaseChargerAvailable);
    };

    
    public boolean isInternalChargerAvailable() {
        return getSensorBoolean(SENSORID_internalChargerAvailable);
    };

    
    public boolean isLeftWheelOvercurrent() {
        return getSensorBoolean(SENSORID_leftWheelOvercurrent);
    };

    
    public boolean isLowSideDriver0Overcurrent() {
        return getSensorBoolean(SENSORID_lowSideDriver0Overcurrent);
    };

    
    public boolean isLowSideDriver1Overcurrent() {
        return getSensorBoolean(SENSORID_lowSideDriver1Overcurrent);
    };

    
    public boolean isLowSideDriver2Overcurrent() {
        return getSensorBoolean(SENSORID_lowSideDriver2Overcurrent);
    };

    
    public boolean isPlayButtonDown() {
        return getSensorBoolean(SENSORID_playButton);
    };

    
    public boolean isRightWheelOvercurrent() {
        return getSensorBoolean(SENSORID_rightWheelOvercurrent);
    };

    
    public boolean isSongPlaying() {
        return getSensorBoolean(SENSORID_songPlaying);
    };

    
    public boolean isVirtualWall() {
        return getSensorBoolean(SENSORID_virtualWall);
    };

    
    public boolean isWheelDropCaster() {
        return getSensorBoolean(SENSORID_wheelDropCaster);
    };

    
    public boolean isWheelDropLeft() {
        return getSensorBoolean(SENSORID_wheelDropLeft);
    };

    
    public boolean isWheelDropRight() {
        return getSensorBoolean(SENSORID_wheelDropRight);
    };

    
    public void leds(boolean powerLedOn, boolean playLedOn, boolean advanceLedOn) {
        leds(0, powerLedOn?255:0, playLedOn, advanceLedOn);
    };

    
    public void leds(int powerColor, int powerIntensity, boolean playLedOn, boolean advanceLedOn) {
        if (IRobotCreateConstants.DEBUG) {
            System.out.print("leds: play led-");
            System.out.print(playLedOn);
            System.out.print(" advance led-");
            System.out.print(advanceLedOn);
            System.out.print(" power color: ");
            System.out.print(powerColor);
            System.out.print(" power intensity: ");
            System.out.println(powerIntensity);
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_LEDS);
        serialConnection.sendByte((advanceLedOn?8:0) | (playLedOn?2:0));
        serialConnection.sendByte(powerColor);
        serialConnection.sendByte(powerIntensity);
        serialConnection.afterCommandPause();
    };

    
    public void lowSideDrivers(boolean lowSideDriver0On, boolean lowSideDriver1On, boolean lowSideDriver2On) {
        if (IRobotCreateConstants.DEBUG) {
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_LOW_SIDE_DRIVERS);
        serialConnection.sendByte((lowSideDriver0On ? IRobotCreateConstants.LOW_SIDE_DRIVER0:0) | (lowSideDriver1On ? IRobotCreateConstants.LOW_SIDE_DRIVER1:0) | (lowSideDriver2On ? IRobotCreateConstants.LOW_SIDE_DRIVER2:0));
        serialConnection.afterCommandPause();
    };

    
    public void pauseResumeStream(boolean pause) {
        if (IRobotCreateConstants.DEBUG) {
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_PAUSE_RESUME_STREAM);
        serialConnection.sendByte(pause?0:1);
    };

    
    public int playScript() {
        if (!serialConnection.isRecording()) {
            throw new IllegalStateException("No bytes recorded");
        }
        if (IRobotCreateConstants.DEBUG) {
            System.out.println("playScript");
        };
        int count = serialConnection.stopRecording();
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_SCRIPT);
        serialConnection.sendByte(count);
        serialConnection.sendBytes(serialConnection.getRecordedBytes(), 0, count);
        serialConnection.afterCommandPause();
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_PLAY_SCRIPT);
        serialConnection.afterCommandPause();
        return count;
    };
    
    public void playSong(int songNumber) {
        if (IRobotCreateConstants.DEBUG) {
            System.out.print("playSong: ");
            System.out.println(songNumber);
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_PLAY_SONG);
        serialConnection.sendByte(songNumber);
        serialConnection.afterCommandPause();
    };
    
    public void pwmLowSideDrivers(int lowSideDriver0DutyCycle, int lowSideDriver1DutyCycle, int lowSideDriver2DutyCycle) {
        if (IRobotCreateConstants.DEBUG) {
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_PWM_LOW_SIDE_DRIVERS);
        serialConnection.sendByte(lowSideDriver2DutyCycle);
        serialConnection.sendByte(lowSideDriver1DutyCycle);
        serialConnection.sendByte(lowSideDriver0DutyCycle);
        serialConnection.afterCommandPause();
    };

    
    public void queryList(int[] packetIds, IRobotCreateEventHandler eventHandler) {
        if (IRobotCreateConstants.DEBUG) {
            System.out.print("queryList:");
            for (int i=0; i < packetIds.length; i++) {
                System.out.print(", ");
                System.out.print(packetIds[i]);
            }
            System.out.println();
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_QUERY_LIST);
        serialConnection.sendByte(packetIds.length);
        serialConnection.sendBytes(packetIds, 0, packetIds.length);
        serialConnection.afterCommandPause();
        updateSensors(packetIds, eventHandler);
    };

    
    protected void resetSensorUpdatedState() {
        for (int i=0; i < NUMBER_OF_SENSORS; i++) {
            sensorUpdatedFlags[i] = false;
        }
    };

    
    public void safe() {
        if (IRobotCreateConstants.DEBUG) {
            System.out.println("safe");
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_MODE_SAFE);
        serialConnection.afterCommandPause();
    };

    
    public void sendIr(int byteValue) {
        if (IRobotCreateConstants.DEBUG) {
            System.out.print("sendIr: ");
            System.out.println(byteValue);
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_SEND_IR);
        serialConnection.sendByte(byteValue);
        serialConnection.afterCommandPause();
    };

    
    public void sensors(int packetId, IRobotCreateEventHandler eventHandler) {
        if (IRobotCreateConstants.DEBUG) {
            System.out.print("sensors: ");
            System.out.println(packetId);
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_SENSORS);
        serialConnection.sendByte(packetId);
        serialConnection.afterCommandPause();
        updateSensor(packetId, eventHandler);
    };

    
    public void setCliffSignalHysteresis(int hysteresis) {
        this.cliffSignalHysteresis = hysteresis;
    };

    
    protected void setSensorBoolean(int sensorId, boolean value, IRobotCreateEventHandler eventHandler) {
        int intValue = value?1:0;
        int oldValue = sensorValues[sensorId];
        sensorUpdatedFlags[sensorId] = true;
        if (oldValue != intValue) {
            sensorValues[sensorId] = intValue;
            dispatchEvent(sensorId, oldValue, intValue, eventHandler);
        }
    };

    
    protected void setSensorInteger(int sensorId, int value, int hysterisis, IRobotCreateEventHandler eventHandler) {
        int oldValue = sensorValues[sensorId];
        sensorUpdatedFlags[sensorId] = true;
        if (Math.abs(oldValue - value) >= hysterisis) {
            sensorValues[sensorId] = value;
            dispatchEvent(sensorId, oldValue, value, eventHandler);
        }
    };

    
    protected void setSensorInteger(int sensorId, int value, IRobotCreateEventHandler eventHandler) {
        int oldValue = sensorValues[sensorId];
        sensorUpdatedFlags[sensorId] = true;
        if (oldValue != value) {
            sensorValues[sensorId] = value;
            dispatchEvent(sensorId, oldValue, value, eventHandler);
        }
    };

    
    public void setVelocity(int velocity) {
        System.out.print("setVelocity: ");
        System.out.println(velocity);
        this.velocity = Math.max(0, Math.min(velocity, IRobotCreateConstants.DRIVE_MAX_VELOCITY));
    };

    
    public void setWallSignalHysteresis(int hysteresis) {
        this.wallSignalHysteresis = hysteresis;
    }
    
    public int[] showScript() {
        if (IRobotCreateConstants.DEBUG) {
            System.out.println("showScript");
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_SHOW_SCRIPT);
        serialConnection.afterCommandPause();
        int size = serialConnection.readUnsignedByte();
        int[] script = new int[size];
        serialConnection.readUnsignedBytes(script, 0, size);
        return script;
    }
    
    public void song(int songNumber, int[] notes, int startIndex, int length) {
        if (IRobotCreateConstants.DEBUG) {
            System.out.println("song");
        };
        if (songNumber < 0 || songNumber > 15) {
            throw new IllegalArgumentException("songNumber " + songNumber);
        }
        if (length < 1 || length > 16) {
            throw new IllegalArgumentException("length " + songNumber);
        }
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_SONG);
        serialConnection.sendByte(notes.length);
        serialConnection.sendBytes(notes, startIndex, length);
        serialConnection.afterCommandPause();
    }

    public void spinLeft() throws IOException {
        drive(velocity, IRobotCreateConstants.DRIVE_TURN_IN_PLACE_COUNTER_CLOCKWISE);
    }
    
    public void spinRight() throws IOException {
        drive(velocity, IRobotCreateConstants.DRIVE_TURN_IN_PLACE_CLOCKWISE);
    }
    
    public void spot() {
        if (IRobotCreateConstants.DEBUG) {
            System.out.println("spot");
        };
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_DEMO_SPOT_COVER);
        serialConnection.afterCommandPause();
    }
    
    public void startRecordingScript() {
        if (IRobotCreateConstants.DEBUG) {
            System.out.println("startRecordingScript");
        };
        serialConnection.startRecording();
    }
    
    public void stop() throws IOException {
        driveDirect(0, 0);
    }
    
    public int stopRecordingScript() {
        if (IRobotCreateConstants.DEBUG) {
            System.out.println("stopRecordingScript");
        };
        return serialConnection.stopRecording();
    }
    
    public void stream(int[] packetTypes) {
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_STREAM);
        serialConnection.sendByte(packetTypes.length);
        serialConnection.sendBytes(packetTypes, 0, packetTypes.length);
        serialConnection.afterCommandPause();
    }
    
    protected void updateSensor(int sensorPacketId, IRobotCreateEventHandler eventHandler) {
        resetSensorUpdatedState();
        updateSensorPrim(sensorPacketId, eventHandler);
    }
    
    protected void updateSensorPrim(int sensorPacketId, IRobotCreateEventHandler eventHandler) {
        int dataByte, dataWord;
        
        switch (sensorPacketId) {
        case IRobotCreateConstants.SENSORS_GROUP_ID0:
            updateSensorPrim(IRobotCreateConstants.SENSORS_BUMPS_AND_WHEEL_DROPS, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_WALL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_LEFT, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_FRONT_LEFT, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_FRONT_RIGHT, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_RIGHT, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_VIRTUAL_WALL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_LOWS_SIDE_DRIVER_AND_WHEEL_OVERCURRENTS, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_UNUSED1, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_UNUSED2, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_INFRARED_BYTE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_BUTTONS, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_DISTANCE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_ANGLE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CHARGING_STATE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_VOLTAGE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CURRENT, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_BATTERY_TEMPERATURE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_BATTERY_CHARGE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_BATTERY_CAPACITY, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_GROUP_ID1:
            updateSensorPrim(IRobotCreateConstants.SENSORS_BUMPS_AND_WHEEL_DROPS, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_WALL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_LEFT, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_FRONT_LEFT, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_FRONT_RIGHT, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_RIGHT, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_VIRTUAL_WALL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_LOWS_SIDE_DRIVER_AND_WHEEL_OVERCURRENTS, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_UNUSED1, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_UNUSED2, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_GROUP_ID2:
            updateSensorPrim(IRobotCreateConstants.SENSORS_INFRARED_BYTE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_BUTTONS, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_DISTANCE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_ANGLE, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_GROUP_ID3:
            updateSensorPrim(IRobotCreateConstants.SENSORS_CHARGING_STATE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_VOLTAGE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CURRENT, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_BATTERY_TEMPERATURE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_BATTERY_CHARGE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_BATTERY_CAPACITY, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_GROUP_ID4:
            updateSensorPrim(IRobotCreateConstants.SENSORS_WALL_SIGNAL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_LEFT_SIGNAL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_FRONT_LEFT_SIGNAL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_FRONT_RIGHT_SIGNAL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_RIGHT_SIGNAL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CARGO_BAY_DIGITAL_INPUTS, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CARGO_BAY_ANALOG_SIGNAL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CHARGING_SOURCES_AVAILABLE, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_GROUP_ID5:
            updateSensorPrim(IRobotCreateConstants.SENSORS_OI_MODE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_SONG_NUMBER, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_SONG_PLAYING, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_NUMBER_OF_STREAM_PACKETS, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_REQUESTED_VELOCITY, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_REQUESTED_RADIUS, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_REQUESTED_RIGHT_VELOCITY, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_REQUESTED_LEFT_VELOCITY, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_GROUP_ID6:
            updateSensorPrim(IRobotCreateConstants.SENSORS_BUMPS_AND_WHEEL_DROPS, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_WALL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_LEFT, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_FRONT_LEFT, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_FRONT_RIGHT, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_RIGHT, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_VIRTUAL_WALL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_LOWS_SIDE_DRIVER_AND_WHEEL_OVERCURRENTS, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_UNUSED1, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_UNUSED2, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_INFRARED_BYTE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_BUTTONS, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_DISTANCE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_ANGLE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CHARGING_STATE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_VOLTAGE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CURRENT, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_BATTERY_TEMPERATURE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_BATTERY_CHARGE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_BATTERY_CAPACITY, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_WALL_SIGNAL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_LEFT_SIGNAL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_FRONT_LEFT_SIGNAL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_FRONT_RIGHT_SIGNAL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CLIFF_RIGHT_SIGNAL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CARGO_BAY_DIGITAL_INPUTS, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CARGO_BAY_ANALOG_SIGNAL, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_CHARGING_SOURCES_AVAILABLE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_OI_MODE, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_SONG_NUMBER, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_SONG_PLAYING, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_NUMBER_OF_STREAM_PACKETS, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_REQUESTED_VELOCITY, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_REQUESTED_RADIUS, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_REQUESTED_RIGHT_VELOCITY, eventHandler);
            updateSensorPrim(IRobotCreateConstants.SENSORS_REQUESTED_LEFT_VELOCITY, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_BUMPS_AND_WHEEL_DROPS:
            dataByte = serialConnection.readUnsignedByte();
            setSensorBoolean(SENSORID_bumpRight, (dataByte & 0x01) != 0, eventHandler);
            setSensorBoolean(SENSORID_bumpLeft, (dataByte & 0x02) != 0, eventHandler);
            setSensorBoolean(SENSORID_wheelDropRight,  (dataByte & 0x04) != 0, eventHandler);
            setSensorBoolean(SENSORID_wheelDropLeft, (dataByte & 0x08) != 0, eventHandler);
            setSensorBoolean(SENSORID_wheelDropCaster, (dataByte & 0x10) != 0, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_WALL:
            dataByte = serialConnection.readUnsignedByte();
            setSensorBoolean(SENSORID_wall, (dataByte & 0x01) != 0, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_CLIFF_LEFT:
            dataByte = serialConnection.readUnsignedByte();
            setSensorBoolean(SENSORID_cliffLeft, (dataByte & 0x01) != 0, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_CLIFF_FRONT_LEFT:
            dataByte = serialConnection.readUnsignedByte();
            setSensorBoolean(SENSORID_cliffFrontLeft, (dataByte & 0x01) != 0, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_CLIFF_FRONT_RIGHT:
            dataByte = serialConnection.readUnsignedByte();
            setSensorBoolean(SENSORID_cliffFrontRight, (dataByte & 0x01) != 0, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_CLIFF_RIGHT:
            dataByte = serialConnection.readUnsignedByte();
            setSensorBoolean(SENSORID_cliffRight, (dataByte & 0x01) != 0, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_VIRTUAL_WALL:
            dataByte = serialConnection.readUnsignedByte();
            setSensorBoolean(SENSORID_virtualWall, (dataByte & 0x01) != 0, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_LOWS_SIDE_DRIVER_AND_WHEEL_OVERCURRENTS:
            dataByte = serialConnection.readUnsignedByte();
            setSensorBoolean(SENSORID_lowSideDriver0Overcurrent, (dataByte & 0x02) != 0, eventHandler);
            setSensorBoolean(SENSORID_lowSideDriver1Overcurrent, (dataByte & 0x01) != 0, eventHandler);
            setSensorBoolean(SENSORID_lowSideDriver2Overcurrent, (dataByte & 0x04) != 0, eventHandler);
            setSensorBoolean(SENSORID_rightWheelOvercurrent, (dataByte & 0x08) != 0, eventHandler);
            setSensorBoolean(SENSORID_leftWheelOvercurrent, (dataByte & 0x10) != 0, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_UNUSED1:
            serialConnection.readUnsignedByte();
            break;
        case IRobotCreateConstants.SENSORS_UNUSED2:
            serialConnection.readUnsignedByte();
            break;
        case IRobotCreateConstants.SENSORS_INFRARED_BYTE:
            setSensorInteger(SENSORID_infraredByte, serialConnection.readUnsignedByte(), eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_BUTTONS:
            dataByte = serialConnection.readUnsignedByte();
            setSensorBoolean(SENSORID_playButton, (dataByte & 0x01) != 0, eventHandler);
            setSensorBoolean(SENSORID_advanceButton, (dataByte & 0x04) != 0, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_DISTANCE:
            dataWord = serialConnection.readSignedWord();
            setSensorInteger(SENSORID_distance, dataWord, eventHandler);
            if (dataWord == -32768) {
                accumulatedDistance = Integer.MIN_VALUE;
            } else if (dataWord == 32767) {
                accumulatedDistance = Integer.MAX_VALUE;
            } else {
                accumulatedDistance += dataWord;
            }
            break;
        case IRobotCreateConstants.SENSORS_ANGLE:
            dataWord = serialConnection.readSignedWord();
            setSensorInteger(SENSORID_angle, dataWord, eventHandler);
            if (dataWord == -32768) {
                accumulatedAngle = Integer.MIN_VALUE;
            } else if (dataWord == 32767) {
                accumulatedAngle = Integer.MAX_VALUE;
            } else {
                accumulatedAngle += dataWord;
            }
            break;
        case IRobotCreateConstants.SENSORS_CHARGING_STATE:
            setSensorInteger(SENSORID_chargingState, serialConnection.readUnsignedByte(), eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_VOLTAGE:
            setSensorInteger(SENSORID_voltage, serialConnection.readUnsignedWord(), eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_CURRENT:
            setSensorInteger(SENSORID_current, serialConnection.readSignedWord(), eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_BATTERY_TEMPERATURE:
            setSensorInteger(SENSORID_batteryTemperature, serialConnection.readSignedByte(), eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_BATTERY_CHARGE:
            setSensorInteger(SENSORID_batteryCharge, serialConnection.readUnsignedWord(), eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_BATTERY_CAPACITY:
            setSensorInteger(SENSORID_batteryCapacity, serialConnection.readUnsignedWord(), eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_WALL_SIGNAL:
            setSensorInteger(SENSORID_wallSignal, serialConnection.readUnsignedWord(), wallSignalHysteresis, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_CLIFF_LEFT_SIGNAL:
            setSensorInteger(SENSORID_cliffLeftSignal, serialConnection.readUnsignedWord(), cliffSignalHysteresis, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_CLIFF_FRONT_LEFT_SIGNAL:
            setSensorInteger(SENSORID_cliffFrontLeftSignal, serialConnection.readUnsignedWord(), cliffSignalHysteresis, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_CLIFF_FRONT_RIGHT_SIGNAL:
            setSensorInteger(SENSORID_cliffFrontRightSignal, serialConnection.readUnsignedWord(), cliffSignalHysteresis, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_CLIFF_RIGHT_SIGNAL:
            setSensorInteger(SENSORID_cliffRightSignal, serialConnection.readUnsignedWord(), cliffSignalHysteresis, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_CARGO_BAY_DIGITAL_INPUTS:
            dataByte = serialConnection.readUnsignedByte();
            setSensorBoolean(SENSORID_cargoBayDigitalInput0, (dataByte & 0x01) != 0, eventHandler);
            setSensorBoolean(SENSORID_cargoBayDigitalInput1, (dataByte & 0x02) != 0, eventHandler);
            setSensorBoolean(SENSORID_cargoBayDigitalInput2, (dataByte & 0x04) != 0, eventHandler);
            setSensorBoolean(SENSORID_cargoBayDigitalInput3, (dataByte & 0x08) != 0, eventHandler);
            setSensorBoolean(SENSORID_cargoBayDeviceDetectBaudRateChange, (dataByte & 0x10) != 0, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_CARGO_BAY_ANALOG_SIGNAL:
            setSensorInteger(SENSORID_cargoBayAnalogSignal, serialConnection.readUnsignedWord(), eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_CHARGING_SOURCES_AVAILABLE:
            dataByte = serialConnection.readUnsignedByte();
            setSensorBoolean(SENSORID_internalChargerAvailable, (dataByte & 0x01) != 0, eventHandler);
            setSensorBoolean(SENSORID_homeBaseChargerAvailable, (dataByte & 0x02) != 0, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_OI_MODE:
            setSensorInteger(SENSORID_oiMode, serialConnection.readUnsignedByte(), eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_SONG_NUMBER:
            setSensorInteger(SENSORID_songNumber, serialConnection.readUnsignedByte(), eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_SONG_PLAYING:
            dataByte = serialConnection.readUnsignedByte();
            setSensorBoolean(SENSORID_songPlaying, (dataByte & 0x01) != 0, eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_NUMBER_OF_STREAM_PACKETS:
            setSensorInteger(SENSORID_numberOfStreamPackets, serialConnection.readUnsignedByte(), eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_REQUESTED_VELOCITY:
            setSensorInteger(SENSORID_requestedVelocity, serialConnection.readSignedWord(), eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_REQUESTED_RADIUS:
            setSensorInteger(SENSORID_requestedRadius, serialConnection.readSignedWord(), eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_REQUESTED_RIGHT_VELOCITY:
            setSensorInteger(SENSORID_requestedRightVelocity, serialConnection.readSignedWord(), eventHandler);
            break;
        case IRobotCreateConstants.SENSORS_REQUESTED_LEFT_VELOCITY:
            setSensorInteger(SENSORID_requestedLeftVelocity, serialConnection.readSignedWord(), eventHandler);
            break;
        default:
            throw new IllegalArgumentException(String.valueOf(sensorPacketId));
        }
    }
    
    protected void updateSensors(int[] sensorPacketIds, IRobotCreateEventHandler eventHandler) {
        resetSensorUpdatedState();
        for (int i=0, length = sensorPacketIds.length; i < length; i++) {
            updateSensorPrim(sensorPacketIds[i], eventHandler);
        }
    }

    public void waitAngle(int degrees) {
        if (IRobotCreateConstants.DEBUG) {
            System.out.print("waitAngle: ");
            System.out.println(degrees);
        };
        // TODO
        // When create turns right, it increments the angle parameter passed in
        // Will keep turning until the angle variable goes to 0
        boolean doScript = false;
        if (!serialConnection.isRecording) {
            doScript = true;
            startRecordingScript();
        }
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_WAIT_ANGLE);
        serialConnection.sendByte(degrees >> 8);
        serialConnection.sendByte(degrees);
        if (doScript) {
            playScript();
        }
    }
    
    public void waitDistance(int mms) {
        if (IRobotCreateConstants.DEBUG) {
            System.out.print("waitDistance: ");
            System.out.println(mms);
        };
        boolean doScript = false;
        if (!serialConnection.isRecording()) {
            doScript = true;
            startRecordingScript();
        }
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_WAIT_DISTANCE);
        serialConnection.sendByte(mms >> 8);
        serialConnection.sendByte(mms & 0xFF);
        if (doScript) {
            playScript();
        }
    }

    public void waitEvent(int event) {
        if (IRobotCreateConstants.DEBUG) {
            System.out.print("waitEvent: ");
            System.out.println(event);
        };
        boolean doScript = false;
        if (!serialConnection.isRecording()) {
            doScript = true;
            startRecordingScript();
        }
        serialConnection.sendByte(IRobotCreateConstants.COMMAND_WAIT_EVENT);
        serialConnection.sendByte(event);
        if (doScript) {
            playScript();
        }
    }
    
    public void waitEventNot(int event) {
        waitEvent(-event);
    }
    
    public void waitTimeMilliseconds(int ms) {
        if (IRobotCreateConstants.DEBUG) {
            System.out.print("waitTimeMilliseconds: ");
            System.out.println(ms);
        };
        if (serialConnection.isRecording()) {
            serialConnection.sendByte(IRobotCreateConstants.COMMAND_WAIT_TIME);
            // TODO: Max 255 * 100 ms
            serialConnection.sendByte(ms / 100);
        } else {
            serialConnection.sleep(ms);
        }
    }

    public void waitTimeSeconds(double seconds) {
        int milliseconds = (int) (seconds * 1000);
        waitTimeMilliseconds(milliseconds);
    }

    public boolean wall() {
        return getSensorBoolean(SENSORID_wall);
    }

}