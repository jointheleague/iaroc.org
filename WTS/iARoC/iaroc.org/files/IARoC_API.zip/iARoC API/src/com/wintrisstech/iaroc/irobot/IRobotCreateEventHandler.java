package com.wintrisstech.iaroc.irobot;


public class IRobotCreateEventHandler {
    protected boolean debug;

    public void advanceButtonEvent(boolean oldBoolean, boolean advanceButton) {
        if (debug) {
            System.out.print("advanceButton:");
            System.out.println(advanceButton);
        }
    }
    
    public void angleEvent(int oldInt, int angle) {
        if (debug) {
            System.out.print("angle:");
            System.out.println(angle);
        }
    }

    public void batteryCapacityEvent(int oldInt, int batteryCapacity) {
        if (debug) {
            System.out.print("batteryCapacity:");
            System.out.println(batteryCapacity);
        }
    }

    public void batteryChargeEvent(int oldInt, int batteryCharge) {
        if (debug) {
            System.out.print("batteryCharge:");
            System.out.println(batteryCharge);
        }
    }

    public void batteryTemperatureEvent(int oldInt, int batteryTemperature) {
        if (debug) {
            System.out.print("batteryTemperature:");
            System.out.println(batteryTemperature);
        }
    }

    public void bumpLeftEvent(boolean oldBoolean, boolean bumpLeft) {
        if (debug) {
            System.out.print("bumpLeft:");
            System.out.println(bumpLeft);
        }
    }

    public void bumpRightEvent(boolean oldBoolean, boolean bumpRight) {
        if (debug) {
            System.out.print("bumpRight:");
            System.out.println(bumpRight);
        }
    }

    public void cargoBayAnalogSignalEvent(int oldInt, int cargoBayAnalogSignal) {
        if (debug) {
            System.out.print("cargoBayAnalogSignal:");
            System.out.println(cargoBayAnalogSignal);
        }
    }

    public void cargoBayDeviceDetectBaudRateChangeEvent(boolean oldBoolean, boolean cargoBayDeviceDetectBaudRateChange) {
        if (debug) {
            System.out.print("cargoBayDeviceDetectBaudRateChange:");
            System.out.println(cargoBayDeviceDetectBaudRateChange);
        }
    }

    public void cargoBayDigitalInput0Event(boolean oldBoolean, boolean cargoBayDigitalInput0) {
        if (debug) {
            System.out.print("cargoBayDigitalInput0:");
            System.out.println(cargoBayDigitalInput0);
        }
    }

    public void cargoBayDigitalInput1Event(boolean oldBoolean, boolean cargoBayDigitalInput1) {
        if (debug) {
            System.out.print("cargoBayDigitalInput1:");
            System.out.println(cargoBayDigitalInput1);
        }
    }

    public void cargoBayDigitalInput2Event(boolean oldBoolean, boolean cargoBayDigitalInput2) {
        if (debug) {
            System.out.print("cargoBayDigitalInput2:");
            System.out.println(cargoBayDigitalInput2);
        }
    }

    public void cargoBayDigitalInput3Event(boolean oldBoolean, boolean cargoBayDigitalInput3) {
        if (debug) {
            System.out.print("cargoBayDigitalInput3:");
            System.out.println(cargoBayDigitalInput3);
        }
    }

    public void chargingStateEvent(int oldInt, int chargingState) {
        if (debug) {
            System.out.print("chargingState:");
            System.out.println(chargingState);
        }
    }

    public void cliffFrontLeftEvent(boolean oldBoolean, boolean cliffFrontLeft) {
        if (debug) {
            System.out.print("cliffFrontLeft:");
            System.out.println(cliffFrontLeft);
        }
    }

    public void cliffFrontLeftSignalEvent(int oldInt, int cliffFrontLeftSignal) {
        if (debug) {
            System.out.print("cliffFrontLeftSignal:");
            System.out.println(cliffFrontLeftSignal);
        }
    }

    public void cliffFrontRightEvent(boolean oldBoolean, boolean cliffFrontRight) {
        if (debug) {
            System.out.print("cliffFrontRight:");
            System.out.println(cliffFrontRight);
        }
    }

    public void cliffFrontRightSignalEvent(int oldInt, int cliffFrontRightSignal) {
        if (debug) {
            System.out.print("cliffFrontRightSignal:");
            System.out.println(cliffFrontRightSignal);
        }
    }

    public void cliffLeftEvent(boolean oldBoolean, boolean cliffLeft) {
        if (debug) {
            System.out.print("cliffLeft:");
            System.out.println(cliffLeft);
        }
    }

    public void cliffLeftSignalEvent(int oldInt, int cliffLeftSignal) {
        if (debug) {
            System.out.print("cliffLeftSignal:");
            System.out.println(cliffLeftSignal);
        }
    }

    public void cliffRightEvent(boolean oldBoolean, boolean cliffRight) {
        if (debug) {
            System.out.print("cliffRight:");
            System.out.println(cliffRight);
        }
    }

    public void cliffRightSignalEvent(int oldInt, int cliffRightSignal) {
        if (debug) {
            System.out.print("cliffRightSignal:");
            System.out.println(cliffRightSignal);
        }
    }

    public void currentEvent(int oldInt, int current) {
        if (debug) {
            System.out.print("current:");
            System.out.println(current);
        }
    }

    public void distanceEvent(int oldInt, int distance) {
        if (debug) {
            System.out.print("distance:");
            System.out.println(distance);
        }
    }

    public void eventBatchEnd() {
        if (debug) {
            System.out.println("eventBatchEnd");
        }
    }

    public void eventBatchStart() {
        if (debug) {
            System.out.println("eventBatchStart");
        }
    }

    public void homeBaseChargerAvailableEvent(boolean oldBoolean, boolean homeBaseChargerAvailable) {
        if (debug) {
            System.out.print("homeBaseChargerAvailable:");
            System.out.println(homeBaseChargerAvailable);
        }
    }

    public void infraredByteEvent(int oldInt, int infraredByte) {
        if (debug) {
            System.out.print("infraredByte:");
            System.out.println(infraredByte);
        }
    }

    public void internalChargerAvailableEvent(boolean oldBoolean, boolean internalChargerAvailable) {
        if (debug) {
            System.out.print("internalChargerAvailable:");
            System.out.println(internalChargerAvailable);
        }
    }

    public void leftWheelOvercurrentEvent(boolean oldBoolean, boolean leftWheelOvercurrent) {
        if (debug) {
            System.out.print("leftWheelOvercurrent:");
            System.out.println(leftWheelOvercurrent);
        }
    }

    public void lowSideDriver0OvercurrentEvent(boolean oldBoolean, boolean lowSideDriver0Overcurrent) {
        if (debug) {
            System.out.print("lowSideDriver0Overcurrent:");
            System.out.println(lowSideDriver0Overcurrent);
        }
    }

    public void lowSideDriver1OvercurrentEvent(boolean oldBoolean, boolean lowSideDriver1Overcurrent) {
        if (debug) {
            System.out.print("lowSideDriver1Overcurrent:");
            System.out.println(lowSideDriver1Overcurrent);
        }
    }

    public void lowSideDriver2OvercurrentEvent(boolean oldBoolean, boolean lowSideDriver2Overcurrent) {
        if (debug) {
            System.out.print("lowSideDriver2Overcurrent:");
            System.out.println(lowSideDriver2Overcurrent);
        }
    }

    public void numberOfStreamPacketsEvent(int oldInt, int numberOfStreamPackets) {
        if (debug) {
            System.out.print("numberOfStreamPackets:");
            System.out.println(numberOfStreamPackets);
        }
    }

    public void oiModeEvent(int oldInt, int oiMode) {
        if (debug) {
            System.out.print("oiMode:");
            System.out.println(oiMode);
        }
    }

    public void playButtonEvent(boolean oldBoolean, boolean playButton) {
        if (debug) {
            System.out.print("playButton:");
            System.out.println(playButton);
        }
    }

    public void requestedLeftVelocityEvent(int oldInt, int requestedLeftVelocity) {
        if (debug) {
            System.out.print("requestedLeftVelocity:");
            System.out.println(requestedLeftVelocity);
        }
    }

    public void requestedRadiusEvent(int oldInt, int requestedRadius) {
        if (debug) {
            System.out.print("requestedRadius:");
            System.out.println(requestedRadius);
        }
    }

    public void requestedRightVelocityEvent(int oldInt, int requestedRightVelocity) {
        if (debug) {
            System.out.print("requestedRightVelocity:");
            System.out.println(requestedRightVelocity);
        }
    }

    public void requestedVelocityEvent(int oldInt, int requestedVelocity) {
        if (debug) {
            System.out.print("requestedVelocity:");
            System.out.println(requestedVelocity);
        }
    }

    public void rightWheelOvercurrentEvent(boolean oldBoolean, boolean rightWheelOvercurrent) {
        if (debug) {
            System.out.print("rightWheelOvercurrent:");
            System.out.println(rightWheelOvercurrent);
        }
    }

    public void setDebug(boolean debug) {
        this.debug = debug;
    }

    public void songNumberEvent(int oldInt, int songNumber) {
        if (debug) {
            System.out.print("songNumber:");
            System.out.println(songNumber);
        }
    }

    public void songPlayingEvent(boolean oldBoolean, boolean songPlaying) {
        if (debug) {
            System.out.print("songPlaying:");
            System.out.println(songPlaying);
        }
    }

    public void virtualWallEvent(boolean oldBoolean, boolean virtualWall) {
        if (debug) {
            System.out.print("virtualWall:");
            System.out.println(virtualWall);
        }
    }

    public void voltageEvent(int oldInt, int voltage) {
        if (debug) {
            System.out.print("voltage:");
            System.out.println(voltage);
        }
    }

    public void wallEvent(boolean oldBoolean, boolean wall) {
        if (debug) {
            System.out.print("wall:");
            System.out.println(wall);
        }
    }

    public void wallSignalEvent(int oldInt, int wallSignal) {
        if (debug) {
            System.out.print("wallSignal:");
            System.out.println(wallSignal);
        }
    }

    public void wheelDropCasterEvent(boolean oldBoolean, boolean wheelDropCaster) {
        if (debug) {
            System.out.print("wheelDropCaster:");
            System.out.println(wheelDropCaster);
        }
    }

    public void wheelDropLeftEvent(boolean oldBoolean, boolean wheelDropLeft) {
        if (debug) {
            System.out.print("wheelDropLeft:");
            System.out.println(wheelDropLeft);
        }
    }

    public void wheelDropRightEvent(boolean oldBoolean, boolean wheelDropRight) {
        if (debug) {
            System.out.print("wheelDropRight:");
            System.out.println(wheelDropRight);
        }
    }

}
