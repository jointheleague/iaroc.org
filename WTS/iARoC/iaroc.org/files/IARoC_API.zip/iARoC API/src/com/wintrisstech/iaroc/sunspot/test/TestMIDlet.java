package com.wintrisstech.iaroc.sunspot.test;

import com.wintrisstech.iaroc.irobot.IRobotCreateInterface;
import com.wintrisstech.iaroc.irobot.test.IRobotCreateInterfaceTest;
import com.wintrisstech.iaroc.irobot.test.IRobotCreateInterfaceTestReporter;
import com.wintrisstech.iaroc.sunspot.SunSpotIRobotCreateSerialConnection;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/**
 * The startApp method of this class is called by the VM to start the
 * application.
 */
public class TestMIDlet extends MIDlet {

    protected void startApp() throws MIDletStateChangeException {
        IRobotCreateInterfaceTestReporter reporter = getReporter();
        reporter.reportInitializing();
        IRobotCreateInterface create = getCreate();
        reporter.reportDoing();
        try {
//            IRobotCreateInterfaceTest.testBlinkLeds(create, reporter);
//            IRobotCreateInterfaceTest.testMakeSquare(create, reporter);
//            IRobotCreateInterfaceTest.testBumps(create, reporter);
            IRobotCreateInterfaceTest.testSensors(create, reporter);
//            IRobotCreateInterfaceTest.testDrive(create, reporter);
//            IRobotCreateInterfaceTest.testSerialInterfaceViaScript(create, reporter);
            reporter.reportDone();
        } catch (Throwable e) {
            reporter.reportError();
            e.printStackTrace();
        }
    }

    public IRobotCreateInterface getCreate() {
        return SunSpotIRobotCreateSerialConnection.getCreate();
    }
    
    public IRobotCreateInterfaceTestReporter getReporter() {
        return new SunSpotIRobotCreateInterfaceTestReporter();
    }
    
    protected void pauseApp() {
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
    }
    
}
