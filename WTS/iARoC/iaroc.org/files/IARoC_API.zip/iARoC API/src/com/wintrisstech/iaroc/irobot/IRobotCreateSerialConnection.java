package com.wintrisstech.iaroc.irobot;


import com.sun.spot.util.Utils;

public abstract class IRobotCreateSerialConnection {
    protected int[] recordedBytes;
    protected int recordedBytesCount;
    protected boolean isRecording;

    public IRobotCreateSerialConnection() {
        this.recordedBytes = new int[IRobotCreateConstants.MAX_COMMAND_SIZE];
        this.recordedBytesCount = 0;
        isRecording = false;
    }
    
    public abstract void flushRead();
    
    public int[] getRecordedBytes() {
        return recordedBytes;
    }
    
    public int getRecordedBytesCount() {
        return recordedBytesCount;
    }
    
    public boolean isRecording() {
        return isRecording;
    }

    public abstract int readSignedByte();

    public abstract int readUnsignedByte();

    public int readSignedWord() {
        // Java is already twos complement, so no need for any translation
        int signed = ((readSignedByte() << 8) & 0xFFFFFF00) | readSignedByte();
        return signed;
    }
    
    public abstract int readUnsignedBytes(int[] buffer, int start, int length);

    public int readUnsignedWord() {
        int unsigned = (readUnsignedByte() << 8) | readUnsignedByte();
        return unsigned;
    }
    
    public void sendByte(int b) {
        if (isRecording) {
            recordedBytes[recordedBytesCount++] = b;
        } else {
            sendBytePrim(b);
        }
    }
    
    public abstract void sendBytePrim(int b);
    
    public void sendBytes(int[] bytes, int start, int length) {
        if (isRecording) {
            for (; length > 0; start++, length--) {
                recordedBytes[recordedBytesCount++] = bytes[start];
            }
        } else {
            sendBytesPrim(bytes, start, length);
        }
    }
    

    public abstract void sendBytesPrim(int[] bytes, int start, int length);

    public void sendSignedWord(int value) {
        // Java bit representation is already two's complement
        sendByte(value >> 8);
        sendByte(value & 0xFF);
    }
    
    public void sendUnsignedWord(int value) {
        sendByte(value >> 8);
        sendByte(value & 0xFF);
    }
    
    public void afterCommandPause() {
        if(isRecording) {
            return;
        }
        if (IRobotCreateConstants.DEBUG_SERIAL) {
            System.out.println("afterCommandPause");
        }
        Utils.sleep(IRobotCreateConstants.AFTER_COMMAND_PAUSE_TIME);
    }

    public void sleep(int ms) {
        if(isRecording) {
            return;
        }
        if (IRobotCreateConstants.DEBUG_SERIAL) {
            System.out.print("sleep: ");
            System.out.println(ms);
        }
        Utils.sleep(ms);
    }

    public void startRecording() {
        isRecording = true;
    }
    
    public int stopRecording() {
        isRecording = false;
        int count = recordedBytesCount;
        recordedBytesCount = 0;
        return count;
    }
    
}
