package com.wintrisstech.iaroc.irobot;

public interface IRobotCreateConstants {
    /**
     * The DEBUG constant is used to turn on and off debugging output.  We do it this way in order to allow for
     * the resulting code to be as small as possible on deployment when DEBUG is false.
     */
    public static final boolean DEBUG = false;
    public static final boolean DEBUG_SERIAL = false;
    
    public static final int MAX_COMMAND_SIZE = 100;
    
    public static final int COMMAND_RESET = 7;
    public static final int COMMAND_START = 128;
    public static final int COMMAND_BAUD = 129;
    public static final int COMMAND_MODE_CONTROL = 130;
    public static final int COMMAND_MODE_SAFE = 131;
    public static final int COMMAND_MODE_FULL = 132;
    public static final int COMMAND_DEMO_SPOT_COVER = 134;
    public static final int COMMAND_DEMO_COVER = 135;
    public static final int COMMAND_DEMO = 136;
    public static final int COMMAND_DRIVE = 137;
    public static final int COMMAND_LOW_SIDE_DRIVERS = 138;
    public static final int COMMAND_LEDS = 139;
    public static final int COMMAND_SONG = 140;
    public static final int COMMAND_PLAY_SONG = 141;
    public static final int COMMAND_SENSORS = 142;
    public static final int COMMAND_DEMO_COVER_AND_DOCK = 143;
    public static final int COMMAND_PWM_LOW_SIDE_DRIVERS = 144;
    public static final int COMMAND_DRIVE_DIRECT = 145;
    public static final int COMMAND_DIGITAL_OUTPUTS = 147;
    public static final int COMMAND_STREAM = 148;
    public static final int COMMAND_QUERY_LIST = 149;
    public static final int COMMAND_PAUSE_RESUME_STREAM = 150;
    public static final int COMMAND_SEND_IR = 151;
    public static final int COMMAND_SCRIPT = 152;
    public static final int COMMAND_PLAY_SCRIPT = 153;
    public static final int COMMAND_SHOW_SCRIPT = 154;
    public static final int COMMAND_WAIT_TIME = 155;
    public static final int COMMAND_WAIT_DISTANCE = 156;
    public static final int COMMAND_WAIT_ANGLE = 157;
    public static final int COMMAND_WAIT_EVENT = 158;

    public static final int DRIVE_STRAIGHT = 0x8000;
    public static final int DRIVE_TURN_IN_PLACE_CLOCKWISE = 0xFFFF;
    public static final int DRIVE_TURN_IN_PLACE_COUNTER_CLOCKWISE = 0x0001;
    public static final int DRIVE_MAX_VELOCITY = 500;
    public static final int DRIVE_MAX_RADIUS = 2000;

    public static final int DEMO_ABORT = 255;
    public static final int DEMO_COVER = 0;
    public static final int DEMO_COVER_AND_DOCK = 1;
    public static final int DEMO_SPOT_COVER = 2;
    public static final int DEMO_MOUSE = 3;
    public static final int DEMO_DRIVE_FIGURE_EIGHT = 4;
    public static final int DEMO_WIMP = 5;
    public static final int DEMO_HOME = 6;
    public static final int DEMO_TAG = 7;
    public static final int DEMO_PACHEBEL = 8;
    public static final int DEMO_BANJO = 9;

    public static final int EVENT_WHEEL_DROP = 1;
    public static final int EVENT_FRONT_WHEEL_DROP = 2;
    public static final int EVENT_LEFT_WHEEL_DROP = 3;
    public static final int EVENT_RIGHT_WHEEL_DROP = 4;
    public static final int EVENT_BUMP = 5;
    public static final int EVENT_LEFT_BUMP = 6;
    public static final int EVENT_RIGHT_BUMP = 7;
    public static final int EVENT_VIRTUAL_WALL = 8;
    public static final int EVENT_WALL = 9;
    public static final int EVENT_CLIFF = 10;
    public static final int EVENT_LEFT_CLIFF = 11;
    public static final int EVENT_FRONT_LEFT_CLIFF = 12;
    public static final int EVENT_FRONT_RIGHT_CLIFF = 13;
    public static final int EVENT_RIGHT_CLIFF = 14;
    public static final int EVENT_HOME_BASE = 15;
    public static final int EVENT_ADVANCE_BUTTON = 16;
    public static final int EVENT_PLAY_BUTTON = 17;
    public static final int EVENT_DIGITAL_INPUT_0 = 18;
    public static final int EVENT_DIGITAL_INPUT_1 = 19;
    public static final int EVENT_DIGITAL_INPUT_2 = 20;
    public static final int EVENT_DIGITAL_INPUT_3 = 21;
    public static final int EVENT_OI_MODE_PASSIVE = 22;

    public static final int SENSORS_GROUP_ID0 = 0;
    public static final int SENSORS_GROUP_ID1 = 1;
    public static final int SENSORS_GROUP_ID2 = 2;
    public static final int SENSORS_GROUP_ID3 = 3;
    public static final int SENSORS_GROUP_ID4 = 4;
    public static final int SENSORS_GROUP_ID5 = 5;
    public static final int SENSORS_GROUP_ID6 = 6;
    public static final int SENSORS_BUMPS_AND_WHEEL_DROPS = 7;
    public static final int SENSORS_WALL = 8;
    public static final int SENSORS_CLIFF_LEFT = 9;
    public static final int SENSORS_CLIFF_FRONT_LEFT = 10;
    public static final int SENSORS_CLIFF_FRONT_RIGHT = 11;
    public static final int SENSORS_CLIFF_RIGHT = 12;
    public static final int SENSORS_VIRTUAL_WALL = 13;
    public static final int SENSORS_LOWS_SIDE_DRIVER_AND_WHEEL_OVERCURRENTS = 14;
    public static final int SENSORS_UNUSED1 = 15;
    public static final int SENSORS_UNUSED2 = 16;
    public static final int SENSORS_INFRARED_BYTE = 17;
    public static final int SENSORS_BUTTONS = 18;
    public static final int SENSORS_DISTANCE = 19;
    public static final int SENSORS_ANGLE = 20;
    public static final int SENSORS_CHARGING_STATE = 21;
    public static final int SENSORS_VOLTAGE = 22;
    public static final int SENSORS_CURRENT = 23;
    public static final int SENSORS_BATTERY_TEMPERATURE = 24;
    public static final int SENSORS_BATTERY_CHARGE = 25;
    public static final int SENSORS_BATTERY_CAPACITY = 26;
    public static final int SENSORS_WALL_SIGNAL = 27;
    public static final int SENSORS_CLIFF_LEFT_SIGNAL = 28;
    public static final int SENSORS_CLIFF_FRONT_LEFT_SIGNAL = 29;
    public static final int SENSORS_CLIFF_FRONT_RIGHT_SIGNAL = 30;
    public static final int SENSORS_CLIFF_RIGHT_SIGNAL = 31;
    public static final int SENSORS_CARGO_BAY_DIGITAL_INPUTS = 32;
    public static final int SENSORS_CARGO_BAY_ANALOG_SIGNAL = 33;
    public static final int SENSORS_CHARGING_SOURCES_AVAILABLE = 34;
    public static final int SENSORS_OI_MODE = 35;
    public static final int SENSORS_SONG_NUMBER = 36;
    public static final int SENSORS_SONG_PLAYING = 37;
    public static final int SENSORS_NUMBER_OF_STREAM_PACKETS = 38;
    public static final int SENSORS_REQUESTED_VELOCITY = 39;
    public static final int SENSORS_REQUESTED_RADIUS = 40;
    public static final int SENSORS_REQUESTED_RIGHT_VELOCITY = 41;
    public static final int SENSORS_REQUESTED_LEFT_VELOCITY = 42;
    
    public static final int DIGITAL_OUTPUT_PIN0 = 1;
    public static final int DIGITAL_OUTPUT_PIN1 = 2;
    public static final int DIGITAL_OUTPUT_PIN2 = 4;

    public static final int LOW_SIDE_DRIVER0 = 1;
    public static final int LOW_SIDE_DRIVER1 = 2;
    public static final int LOW_SIDE_DRIVER2 = 4;

    public static final int INFRARED_BYTE_REMOTE_CONTROL_LEFT = 129;
    public static final int INFRARED_BYTE_REMOTE_CONTROL_FORWARD = 130;
    public static final int INFRARED_BYTE_REMOTE_CONTROL_RIGHT = 131;
    public static final int INFRARED_BYTE_REMOTE_CONTROL_SPOT = 132;
    public static final int INFRARED_BYTE_REMOTE_CONTROL_MAX = 133;
    public static final int INFRARED_BYTE_REMOTE_CONTROL_SMALL = 134;
    public static final int INFRARED_BYTE_REMOTE_CONTROL_MEDIUM = 135;
    public static final int INFRARED_BYTE_REMOTE_CONTROL_LARGE_CLEAN = 136;
    public static final int INFRARED_BYTE_REMOTE_CONTROL_PAUSE = 137;
    public static final int INFRARED_BYTE_REMOTE_CONTROL_POWER = 138;
    public static final int INFRARED_BYTE_REMOTE_CONTROL_ARC_FORWARD_LEFT = 139;
    public static final int INFRARED_BYTE_REMOTE_CONTROL_ARC_FORWARD_RIGHT = 140;
    public static final int INFRARED_BYTE_REMOTE_CONTROL_DRIVE_STOP = 141;
    public static final int INFRARED_BYTE_SCHEDULING_REMOTE_CONTROL_SEND_ALL = 142;
    public static final int INFRARED_BYTE_SCHEDULING_REMOTE_CONTROL_SEEK_DOCK = 143;
    public static final int INFRARED_BYTE_HOME_BASE_RESERVED = 240;
    public static final int INFRARED_BYTE_HOME_BASE_RED_BUOY = 248;
    public static final int INFRARED_BYTE_HOME_BASE_GREEN_BUOY = 244;
    public static final int INFRARED_BYTE_HOME_BASE_FORCE_FIELD = 242;
    public static final int INFRARED_BYTE_HOME_BASE_RED_GREEN_BUOY = 252;
    public static final int INFRARED_BYTE_HOME_BASE_RED_BUOY_FORCE_FIELD = 250;
    public static final int INFRARED_BYTE_HOME_BASE_GREEN_BUOY_FORCE_FIELD = 246;
    public static final int INFRARED_BYTE_HOME_BASE_RED_GREEN_BUOY_FORCE_FIELD = 254;
    public static final int INFRARED_BYTE_NONE = 255;
    
    public static final int OI_MODE_OFF = 0;
    public static final int OI_MODE_PASSIVE = 1;
    public static final int OI_MODE_SAFE = 2;
    public static final int OI_MODE_FULL = 3;

    public static final int CHARGING_STATE_NOT_CHARGING = 0;
    public static final int CHARGING_STATE_RECONDITIONING_CHARGING = 1;
    public static final int CHARGING_STATE_FULL_CHARGING = 2;
    public static final int CHARGING_STATE_TRICKLE_CHARGING = 3;
    public static final int CHARGING_STATE_WAITING = 4;
    public static final int CHARGING_STATE_CHARGING_FAULT_CONDITION = 5;
    
    public static final int NOTE_G = 31;
    public static final int NOTE_GSHARP = 32;
    public static final int NOTE_A = 33;
    public static final int NOTE_ASHARP = 34;
    public static final int NOTE_B = 35;
    public static final int NOTE_C = 36;
    public static final int NOTE_CSHARP = 37;
    public static final int NOTE_D = 38;
    public static final int NOTE_DSHARP = 39;
    public static final int NOTE_E = 40;
    public static final int NOTE_F = 41;
    public static final int NOTE_FSHARP = 42;
    public static final int NOTE_OCTAVE_SIZE = 12;
    
    public static final int AFTER_COMMAND_PAUSE_TIME = 20;

}
