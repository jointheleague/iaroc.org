package com.wintrisstech.iaroc.sunspot.test;

import com.sun.spot.sensorboard.EDemoBoard;
import com.sun.spot.sensorboard.peripheral.ITriColorLED;
import com.sun.spot.sensorboard.peripheral.LEDColor;
import com.wintrisstech.iaroc.irobot.test.IRobotCreateInterfaceTestReporter;
import com.wintrisstech.iaroc.sunspot.XLights;

public class SunSpotIRobotCreateInterfaceTestReporter extends IRobotCreateInterfaceTestReporter{
    XLights xLights;
    protected boolean reportedError;

    protected XLights getXLights() {
        if (xLights != null) {
            return xLights;
        }
        xLights = new XLights(EDemoBoard.getInstance(), 0, 7);
        xLights.setColor(LEDColor.WHITE);
        xLights.startPsilon();
        return xLights;
    }

    public void reportCounts(int successCount, int ioExceptionCount, int mismatchCount) {
        super.reportCounts(successCount, ioExceptionCount, mismatchCount);
        final int intensity = 63;
        if (xLights != null) {
            xLights.stopPsilon();
            xLights = null;
        }
        ITriColorLED[] leds = EDemoBoard.getInstance().getLEDs();
        int mask = 1;
        for (int i=0; i < leds.length; i++) {
            int r = (mismatchCount & mask) ==0 ?0:intensity;
            int g = (successCount & mask) ==0 ?0:intensity;
            int b = (ioExceptionCount & mask) ==0 ?0:intensity;
            leds[i].setRGB(r, g, b);
            leds[i].setOn();
            mask *= 2;
        }
    }
    
    public void reportInitializing() {
        super.reportInitializing();
        getXLights();
        xLights.setColor(LEDColor.YELLOW);
    }

    public void reportDoing() {
        super.reportDoing();
        getXLights();
        xLights.setColor(LEDColor.GREEN);
    }
    
    public void reportDone() {
        super.reportDone();
        if (reportedError) {
            return;
        }
        getXLights();
        xLights.setColor(LEDColor.BLUE);
    }
    
    public void reportError() {
        super.reportError();
        getXLights();
        xLights.setColor(LEDColor.RED);
        reportedError = true;
    }
    
}
