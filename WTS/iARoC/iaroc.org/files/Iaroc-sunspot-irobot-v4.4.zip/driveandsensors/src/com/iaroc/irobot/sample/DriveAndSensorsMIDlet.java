package com.iaroc.irobot.sample;

import com.iaroc.irobot.IRobotCreate;
import com.iaroc.irobot.IRobotCreateConstants;
import com.iaroc.irobot.IRobotCreateEventHandler;
import com.iaroc.irobot.util.XLights;
import com.sun.spot.sensorboard.EDemoBoard;
import com.sun.spot.sensorboard.peripheral.LEDColor;
import com.sun.spot.util.Utils;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/**
 * Similar application to the iaroc-irobot-bumps (bumps) project, but this one
 * uses an event handler instead of querying each sensor interested in. Tries to
 * get away from contacts on its bumpers. If the left bumper is hit, the robot
 * rotates right until the left bump sensor is released. Opposite direction for
 * right bumper.
 */
public class DriveAndSensorsMIDlet extends MIDlet {
    protected IRobotCreate create;
    protected XLights xLights;
    
    protected void doTest() {
        final int maxVelocity = 100;
        final boolean[] doneFlagHolder = new boolean[1];
        
        IRobotCreateEventHandler eventHandler = new IRobotCreateEventHandler() {
            int rightVelocity = 100;
            int leftVelocity = 100;
            
            public void bumpLeftEvent(boolean oldBoolean, boolean bumpLeft) {
                super.bumpLeftEvent(oldBoolean, bumpLeft);
                if (bumpLeft) {
                    rightVelocity = -maxVelocity;
                    leftVelocity = maxVelocity;
                } else {
                    rightVelocity = maxVelocity;
                    leftVelocity = maxVelocity;
                }
                create.driveDirect(rightVelocity, leftVelocity);
            }
            
            public void bumpRightEvent(boolean oldBoolean, boolean bumpRight) {
                super.bumpRightEvent(oldBoolean, bumpRight);
                if (bumpRight) {
                    rightVelocity = maxVelocity;
                    leftVelocity = -maxVelocity;
                } else {
                    rightVelocity = maxVelocity;
                    leftVelocity = maxVelocity;
                }
                create.driveDirect(rightVelocity, leftVelocity);
            }
            
            public void playButtonEvent(boolean oldBoolean, boolean playButton) {
                super.playButtonEvent(oldBoolean, playButton);
                doneFlagHolder[0] = true;
                create.driveDirect(0, 0);
            }
        };
        create.driveDirect(maxVelocity, maxVelocity);
        while (!doneFlagHolder[0]) {
            create.sensors(IRobotCreateConstants.SENSORS_GROUP_ID6, eventHandler);
            Utils.sleep(50);
        }
        create.drive(0, 0);
    }

    protected void startApp() throws MIDletStateChangeException {
        xLights = new XLights(EDemoBoard.getInstance(), 0, 7);
        xLights.setColor(LEDColor.WHITE);
        xLights.startPsilon();
        System.out.print("Initializing: ");
        System.out.println(this.getClass().getName());
        xLights.setColor(LEDColor.YELLOW);
        try {
            create = new IRobotCreate();
            // Indicate we have connected with the Create and are about to execute our test
            xLights.setColor(LEDColor.GREEN);
            // Run the actual test code we want to do
            doTest();
            // Indicate we are done
            xLights.setColor(LEDColor.BLUE);
        } catch (Throwable e) {
            e.printStackTrace();
            // Indicate we got an error
            xLights.setColor(LEDColor.RED);
        }
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
    }
    
}
