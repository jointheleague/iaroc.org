package com.iaroc.irobot.sample;

import com.iaroc.irobot.IRobotCreate;
import com.iaroc.irobot.IRobotCreateEventHandler;

/**
 * DOES NOT WORK<br>
 * The root class of all states, holding common behavior and information.
 */
public class State extends IRobotCreateEventHandler {
    protected StateMachine stateMachine;
    protected boolean isOnLeft;
    protected boolean isOnRight;

    public State(StateMachine machine) {
        stateMachine = machine;
    }
    
    public void bumpLeftEvent(boolean oldBoolean, boolean bumpLeft) {
        super.bumpLeftEvent(oldBoolean, bumpLeft);
        getStateMachine().setKeepGoing(false);
    }

    public void bumpRightEvent(boolean oldBoolean, boolean bumpRight) {
        super.bumpRightEvent(oldBoolean, bumpRight);
        getStateMachine().setKeepGoing(false);
    }

    public void enter() {
        if (stateMachine.debug) {
            System.out.print("Enter state: ");
            System.out.println(getClass().getName());
        }
    }
    
    public void exit() {
    }
    
    public IRobotCreate getCreate() {
        return stateMachine.getCreate();
    }
    
    public StateMachine getStateMachine() {
        return stateMachine;
    }
    
    public void cliffLeftSignalEvent(int oldInt, int cliffFrontLeftSignal) {
        super.cliffFrontLeftSignalEvent(oldInt, cliffFrontLeftSignal);
        isOnLeft = getStateMachine().isCliffSignalOnLine(cliffFrontLeftSignal, true);
    }

    public void cliffRightSignalEvent(int oldInt, int cliffFrontRightSignal) {
        // TODO Auto-generated method stub
        super.cliffFrontRightSignalEvent(oldInt, cliffFrontRightSignal);
        isOnRight = getStateMachine().isCliffSignalOnLine(cliffFrontRightSignal, false);
    }

    public void playButtonEvent(boolean oldBoolean, boolean playButton) {
        super.playButtonEvent(oldBoolean, playButton);
        if (playButton) {
            getStateMachine().setKeepGoing(false);
        }
    }

}
