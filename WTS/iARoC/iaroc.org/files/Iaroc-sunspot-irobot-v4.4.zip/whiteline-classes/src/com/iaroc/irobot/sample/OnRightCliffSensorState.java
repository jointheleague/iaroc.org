package com.iaroc.irobot.sample;

/**
 * DOES NOT WORK<br>
 * I represent the state of being on the right cliff sensor.
 */
public class OnRightCliffSensorState extends State {

    public OnRightCliffSensorState(StateMachine machine) {
        super(machine);
    }

    public void cliffFrontRightSignalEvent(int oldInt, int cliffFrontRightSignal) {
        super.cliffFrontLeftSignalEvent(oldInt, cliffFrontRightSignal);
        if (isOnRight) {
            getCreate().spinRight();
        } else {
            getCreate().goForward();
            getStateMachine().enterState(getStateMachine().getGoingForwardState());
        }
    }

}
