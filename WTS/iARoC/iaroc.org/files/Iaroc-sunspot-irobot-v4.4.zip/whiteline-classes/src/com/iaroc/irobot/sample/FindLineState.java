package com.iaroc.irobot.sample;

/**
 * DOES NOT WORK<br>
 * I represent the state of the initial finding of the white line.
 */
public class FindLineState extends State {

    public FindLineState(StateMachine machine) {
        super(machine);
    }
    
    public void cliffFrontLeftSignalEvent(int oldInt, int cliffFrontLeftSignal) {
        super.cliffFrontLeftSignalEvent(oldInt, cliffFrontLeftSignal);
        if (getStateMachine().isCliffSignalOnLine(cliffFrontLeftSignal, true)) {
            getCreate().goForward();
            getStateMachine().enterState(getStateMachine().getGoingForwardState());
        }
    }

    public void cliffFrontRightSignalEvent(int oldInt, int cliffFrontRightSignal) {
        super.cliffFrontLeftSignalEvent(oldInt, cliffFrontRightSignal);
        if (getStateMachine().isCliffSignalOnLine(cliffFrontRightSignal, false)) {
            getCreate().goForward();
            getStateMachine().enterState(getStateMachine().getGoingForwardState());
        }
    }

}
