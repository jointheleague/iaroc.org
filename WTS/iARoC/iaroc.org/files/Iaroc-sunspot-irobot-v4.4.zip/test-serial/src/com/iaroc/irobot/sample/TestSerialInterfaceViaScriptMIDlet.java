package com.iaroc.irobot.sample;

import com.iaroc.irobot.IRobotCreate;
import com.iaroc.irobot.util.XLights;
import com.sun.spot.sensorboard.EDemoBoard;
import com.sun.spot.sensorboard.peripheral.LEDColor;
import com.sun.spot.util.Utils;
import com.sun.squawk.util.UnexpectedException;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/**
 * IGNORE<br>
 * Test app we are using to test some flaws we had, but has not been updated in
 * a long time and is likely not to work.
 */
public class TestSerialInterfaceViaScriptMIDlet extends MIDlet {
    protected IRobotCreate create;
    XLights xLights;
    
    protected void doTest() {
        int successCount = 0;
        int ioExceptionCount = 0;
        int mismatchCount = 0;
        int waitTime = 100;
        label:
        while (true) {
            xLights.displayCounts(ioExceptionCount, successCount, mismatchCount);
            create.startRecordingScript();
            for (int i=0; i < 6; i++) {
                create.leds(true, true, true);
                create.waitTimeMilliseconds(waitTime);
                create.leds(false, false, false);
                create.waitTimeMilliseconds(waitTime);
            }
            waitTime += 100;
            if (waitTime > 300) {
                waitTime = 100;
            }
            try {
                int recordedCount = create.playScript();
                create.leds(true, true, true);
                Utils.sleep(2000);
                int[] recordedScript = create.getSerialConnection().getRecordedBytes();
                int[] returnedScript = create.showScript();
                if (recordedCount != returnedScript.length) {
                    mismatchCount++;
                    System.out.println("un-matched length");
                    for (int i=0; i < returnedScript.length; i++) {
                        System.out.println(i + "-" + returnedScript[i]);
                    }
                    continue label;
                }
                for (int i=0; i < recordedCount; i++) {
                    if (recordedScript[i] != returnedScript[i]) {
                        mismatchCount++;
                        System.out.println("un-matched data: sent, received");
                        for (int j=0; j < recordedCount; j++) {
                            System.out.println(j + "-" + recordedScript[j] + ":" + returnedScript[j] + (recordedScript[j] == returnedScript[j]?"":"<<<"));
                        }
                        continue label;
                    }
                }
                successCount++;
            } catch (UnexpectedException e) {
                ioExceptionCount++;
                e.printStackTrace();
            }
        }
    }

    protected void startApp() throws MIDletStateChangeException {
        xLights = new XLights(EDemoBoard.getInstance(), 2, 5);
        xLights.setColor(LEDColor.WHITE);
        xLights.startPsilon();
        System.out.print("Initializing: ");
        System.out.println(this.getClass().getName());
        xLights.setColor(LEDColor.YELLOW);
        try {
            create = new IRobotCreate();
            // Indicate we have not connected with the Create and are about to execute our test
            xLights.setColor(LEDColor.GREEN);
            // Run the actual test code we want to do
            doTest();
            // Indicate we are done
            xLights.setColor(LEDColor.BLUE);
        } catch (Throwable e) {
            e.printStackTrace();
            // Indicate we got an error
            xLights.setColor(LEDColor.RED);
        }
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
    }
    
}
