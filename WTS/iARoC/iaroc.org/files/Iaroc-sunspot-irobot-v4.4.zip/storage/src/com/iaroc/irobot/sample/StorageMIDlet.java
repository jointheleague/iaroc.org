package com.iaroc.irobot.sample;

import com.iaroc.irobot.util.KeyedStorage;
import com.iaroc.irobot.util.XLights;
import com.sun.spot.sensorboard.EDemoBoard;
import com.sun.spot.sensorboard.peripheral.LEDColor;
import com.sun.spot.util.BootloaderListener;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/**
 * Sample application that shows a made up example to work with the
 * {@link KeyedStorage} class. On every run of the program, it appends data to
 * two keys stored persistently. If on application start the SW1 switch is
 * pressed, it will delete the keys found in the persistent store created.
 */
public class StorageMIDlet extends MIDlet {
    protected XLights xLights;
    
    protected void doTest() {
        // In case of using the IRobotCreate class, there is no need to do this
        // as its already done.  We start a BootLoaderListener to reduce the need
        // for you to have to press reset on every deployment of an application
        // to Sun SPOT
        new BootloaderListener().start();
        final String bytesKey = "bytes";
        final String stringKey = "string";
        KeyedStorage keyedStorage = new KeyedStorage("sample");
        if (EDemoBoard.getInstance().getSwitches()[EDemoBoard.SW1].isClosed()) {
            keyedStorage.remove(bytesKey);
            keyedStorage.remove(stringKey);
            System.out.println("removed keys");
            return;
        }
        byte[] bytes = keyedStorage.getBytes(bytesKey);
        if (bytes == null) {
            bytes = new byte[10];
        }
        for (int i=0; i < bytes.length; i++) {
            bytes[i] += i;
        }
        keyedStorage.putBytes(bytesKey, bytes);
        System.out.print(bytesKey);
        System.out.println(':');
        for (int i=0; i < bytes.length; i++) {
            System.out.print('[');
            System.out.print(i);
            System.out.print("]=");
            System.out.println(bytes[i]);
        }
        
        System.out.print(stringKey);
        System.out.print(':');
        String theString = keyedStorage.getString(stringKey);
        if (theString == null) {
            theString = "start:";
        }
        theString = theString + ":" + theString.length();
        keyedStorage.putString(stringKey, theString);
        System.out.println(theString);
    }

    protected void startApp() throws MIDletStateChangeException {
        xLights = new XLights(EDemoBoard.getInstance(), 0, 7);
        xLights.setColor(LEDColor.WHITE);
        xLights.startPsilon();
        System.out.print("Initializing: ");
        System.out.println(this.getClass().getName());
        xLights.setColor(LEDColor.YELLOW);
        try {
            xLights.setColor(LEDColor.GREEN);
            // Run the actual test code we want to do
            doTest();
            // Indicate we are done
            xLights.setColor(LEDColor.BLUE);
        } catch (Throwable e) {
            e.printStackTrace();
            // Indicate we got an error
            xLights.setColor(LEDColor.RED);
        }
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
    }
    
}
