package com.iaroc.irobot.sample;

import com.iaroc.irobot.IRobotCreate;
import com.iaroc.irobot.util.XLights;
import com.sun.spot.sensorboard.EDemoBoard;
import com.sun.spot.sensorboard.peripheral.LEDColor;
import com.sun.spot.util.Utils;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/**
 * <p>
 * Sample application showing the top level usage of an event handler and a
 * simple state machine using simple constants and switch statements. This is
 * not the recommended way of building a state machine, but provides for a
 * simple example using as few classes as possible.
 * </p><p>
 * The way to use this application is to lay down some Foil Tape (can be found
 * in aisle 15 of Home Depot :). This tape is normally used for ducting. It is
 * the only type of tape I was able to find that would support the type of
 * reflection needed to make the white line follower work consistently on most
 * surfaces.
 * </p><p>
 * Once you've set a path with the foil tape, place the robot at the "start" or
 * on the line, making sure the front of the robot is away from the line itself.
 * The robot will rotate right when it starts in order to find the white line.
 * The code assumes that the robot starts by being on dark, then rotates right
 * to find "white", this is the calibration phase. Once the white line has been
 * found by the front left cliff sensor, the robot will force the line to stay
 * within its left and right cliff sensors which are located on 90 degrees from
 * the front.
 * </p>
 */
public class WhiteLineFollowerUsingSwitchesMIDlet extends MIDlet {
    protected IRobotCreate create;
    protected XLights xLights;
    
    protected void doTest() {
        WhiteLineFollowerUsingSwitchesEventHandler follower = new WhiteLineFollowerUsingSwitchesEventHandler(create, EDemoBoard.getInstance());
        follower.start();
        // Loop until the play button is pressed
        while (follower.keepGoing()) {
            follower.pollSensors();
            Utils.sleep(50);
        }
        create.stop();
    }

    protected void startApp() throws MIDletStateChangeException {
        xLights = new XLights(EDemoBoard.getInstance(), 2, 5);
        xLights.setColor(LEDColor.WHITE);
        xLights.startPsilon();
        System.out.print("Initializing: ");
        System.out.println(this.getClass().getName());
        xLights.setColor(LEDColor.YELLOW);
        try {
            create = new IRobotCreate();
            // Indicate we have not connected with the Create and are about to execute our test
            xLights.setColor(LEDColor.GREEN);
            // Run the actual test code we want to do
            doTest();
            // Indicate we are done
            xLights.setColor(LEDColor.BLUE);
        } catch (Throwable e) {
            e.printStackTrace();
            // Indicate we got an error
            xLights.setColor(LEDColor.RED);
        }
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
    }
    
}
