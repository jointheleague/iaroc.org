package com.iaroc.irobot.test;

import com.iaroc.irobot.XLights;
import com.sun.spot.sensorboard.EDemoBoard;
import com.sun.spot.sensorboard.peripheral.ITriColorLED;
import com.sun.spot.sensorboard.peripheral.LEDColor;

public class TestReporter {
    protected XLights xLights;
    protected boolean reportedError;
    
    public TestReporter() {
        xLights = new XLights(EDemoBoard.getInstance(), 0, 7);
        xLights.setColor(LEDColor.WHITE);
        xLights.startPsilon();
    }

    public void report(String string) {
        System.out.println(string);
    }
    
    public void reportCounts(int redCount, int greenCount, int blueCount) {
        System.out.println("Reporting");
        System.out.print("   red: ");
        System.out.println(redCount);
        System.out.print("   green: ");
        System.out.println(greenCount);
        System.out.print("   blue: ");
        System.out.println(blueCount);
        final int intensity = 63;
        if (xLights != null) {
            xLights.stopPsilon();
            xLights = null;
        }
        ITriColorLED[] leds = EDemoBoard.getInstance().getLEDs();
        int mask = 1;
        for (int i=0; i < leds.length; i++) {
            int r = (redCount & mask) ==0 ?0:intensity;
            int g = (greenCount & mask) ==0 ?0:intensity;
            int b = (blueCount & mask) ==0 ?0:intensity;
            leds[i].setRGB(r, g, b);
            leds[i].setOn();
            mask *= 2;
        }
    }
    
    public void reportInitializing(String string) {
        System.out.print("Initializing: ");
        System.out.println(string);
        xLights.setColor(LEDColor.YELLOW);
    }

    public void reportDoing() {
        System.out.println("Doing");
        xLights.setColor(LEDColor.GREEN);
    }
    
    public void reportDone() {
        System.out.println("Done");
        if (reportedError) {
            return;
        }
        xLights.setColor(LEDColor.BLUE);
    }
    
    public void reportError(Throwable t) {
        System.out.println("Error");
        t.printStackTrace();
        xLights.setColor(LEDColor.RED);
        reportedError = true;
    }

}
