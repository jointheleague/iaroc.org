package com.iaroc.irobot.test;

import com.iaroc.irobot.IRobotCreate;
import com.iaroc.irobot.IRobotCreateConstants;
import com.iaroc.irobot.IRobotCreateEventHandler;
import com.iaroc.irobot.test.TestReporter;
import com.sun.spot.util.Utils;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/**
 * The startApp method of this class is called by the VM to start the
 * application.
 */
public class TestSensorsMIDlet extends MIDlet {
    protected IRobotCreate create;
    protected TestReporter reporter;
    
    protected void doTest() {
        // Create an event handler and set it up to output debug info which will report all events
        // that occur
        IRobotCreateEventHandler eventHandler = new IRobotCreateEventHandler();
        eventHandler.setDebug(true);
        // Se the hysteresis values such that we minimize how much output there is,
        // since the wall signal and cliff signals seem to have a lot of noise
        create.setWallSignalHysteresis(2);
        create.setCliffSignalHysteresis(300);
        // Read the state of the buttons, so that the start of the while loop does not
        // cause an exception
        create.sensors(IRobotCreateConstants.SENSORS_BUTTONS, null);
        // Loop until the play button is pressed
        while (!create.isPlayButtonDown()) {
            // The event handler is setup to output debug info, which is what we want, a print
            // of all the events as they occur
            create.sensors(IRobotCreateConstants.SENSORS_GROUP_ID6, eventHandler);
            Utils.sleep(50);
        }
    }

    protected void startApp() throws MIDletStateChangeException {
        // We use a reporter class in order to reduce the duplication of code for all of our tests
        reporter = new TestReporter();
        try {
            // Indicate we are about to initialize our connection to the Create
            reporter.reportInitializing(this.getClass().getName());
            create = new IRobotCreate();
            // Indicate we have not connected with the Create and are about to execute our test
            reporter.reportDoing();
            // Run the actual test code we want to do
            doTest();
            // Indicate we are done
            reporter.reportDone();
        } catch (Throwable e) {
            // Indicate we got an error
            reporter.reportError(e);
        }
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
    }
    
}
