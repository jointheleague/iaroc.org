package com.iaroc.irobot.test;

import com.iaroc.irobot.IRobotCreate;
import com.iaroc.irobot.IRobotCreateConstants;
import com.iaroc.irobot.IRobotCreateEventHandler;
import com.iaroc.irobot.test.TestReporter;
import com.sun.spot.util.Utils;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/**
 * The startApp method of this class is called by the VM to start the
 * application.
 */
public class TestDriveAndSensorsMIDlet extends MIDlet {
    protected IRobotCreate create;
    protected TestReporter reporter;
    
    protected void doTest() {
        final int maxVelocity = 100;
        final boolean[] doneFlagHolder = new boolean[1];
        
        IRobotCreateEventHandler eventHandler = new IRobotCreateEventHandler() {
            int rightVelocity = 100;
            int leftVelocity = 100;
            
            public void bumpLeftEvent(boolean oldBoolean, boolean bumpLeft) {
                super.bumpLeftEvent(oldBoolean, bumpLeft);
                if (bumpLeft) {
                    rightVelocity = -maxVelocity;
                    leftVelocity = maxVelocity;
                } else {
                    rightVelocity = maxVelocity;
                    leftVelocity = maxVelocity;
                }
                try {
                    create.driveDirect(rightVelocity, leftVelocity);
                } catch (Throwable e) {
                    reporter.reportError(e);
                }
            }
            
            public void bumpRightEvent(boolean oldBoolean, boolean bumpRight) {
                super.bumpRightEvent(oldBoolean, bumpRight);
                if (bumpRight) {
                    rightVelocity = maxVelocity;
                    leftVelocity = -maxVelocity;
                } else {
                    rightVelocity = maxVelocity;
                    leftVelocity = maxVelocity;
                }
                try {
                    create.driveDirect(rightVelocity, leftVelocity);
                } catch (Throwable e) {
                    reporter.reportError(e);
                }
            }
            
            public void playButtonEvent(boolean oldBoolean, boolean playButton) {
                super.playButtonEvent(oldBoolean, playButton);
                doneFlagHolder[0] = true;
                try {
                    create.driveDirect(0, 0);
                } catch (Throwable e) {
                    reporter.reportError(e);
                }
            }
        };
        
        try {
            create.driveDirect(maxVelocity, maxVelocity);
            while (!doneFlagHolder[0]) {
                create.sensors(IRobotCreateConstants.SENSORS_GROUP_ID6, eventHandler);
                Utils.sleep(50);
            }
            create.drive(0, 0);
        } catch (Throwable e) {
            reporter.reportError(e);
        }
    }

    protected void startApp() throws MIDletStateChangeException {
        // We use a reporter class in order to reduce the duplication of code for all of our tests
        reporter = new TestReporter();
        try {
            // Indicate we are about to initialize our connection to the Create
            reporter.reportInitializing(this.getClass().getName());
            create = new IRobotCreate();
            // Indicate we have not connected with the Create and are about to execute our test
            reporter.reportDoing();
            // Run the actual test code we want to do
            doTest();
            // Indicate we are done
            reporter.reportDone();
        } catch (Throwable e) {
            // Indicate we got an error
            reporter.reportError(e);
        }
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
    }
    
}
