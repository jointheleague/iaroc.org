package com.iaroc.irobot.test;

import com.iaroc.irobot.IRobotCreate;
import com.iaroc.irobot.test.TestReporter;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/**
 * The startApp method of this class is called by the VM to start the
 * application.
 */
public class TestBlinkLedsMIDlet extends MIDlet {
    protected IRobotCreate create;
    protected TestReporter reporter;
    
    protected void doTest() {
        for (int i=0; i < 10; i++) {
            create.leds(true, true, true);
            create.getSerialConnection().sleep(250);
            create.leds(false, false, false);
            create.getSerialConnection().sleep(250);
        }
    }

    protected void startApp() throws MIDletStateChangeException {
        // We use a reporter class in order to reduce the duplication of code for all of our tests
        reporter = new TestReporter();
        try {
            // Indicate we are about to initialize our connection to the Create
            reporter.reportInitializing(this.getClass().getName());
            create = new IRobotCreate();
            // Indicate we have not connected with the Create and are about to execute our test
            reporter.reportDoing();
            // Run the actual test code we want to do
            doTest();
            // Indicate we are done
            reporter.reportDone();
        } catch (Throwable e) {
            // Indicate we got an error
            reporter.reportError(e);
        }
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
    }
    
}
