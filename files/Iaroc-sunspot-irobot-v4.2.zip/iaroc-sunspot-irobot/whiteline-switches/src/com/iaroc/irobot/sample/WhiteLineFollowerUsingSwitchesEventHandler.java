package com.iaroc.irobot.sample;

import com.iaroc.irobot.IRobotCreate;
import com.iaroc.irobot.IRobotCreateConstants;
import com.iaroc.irobot.IRobotCreateEventHandler;
import com.sun.spot.sensorboard.EDemoBoard;

public class WhiteLineFollowerUsingSwitchesEventHandler extends IRobotCreateEventHandler {
    public static final int STATE_CALIBRATING = 1;
    public static final int STATE_ON_LEFT_CLIFF = 2;
    public static final int STATE_ON_RIGHT_CLIFF = 3;
    public static final int STATE_GOING_FORWARD = 4;
    public static final int STATE_TEST_WHITELINE = 100;
    
    public static final int LED_LEFT = 0;
    public static final int LED_FRONT_LEFT = 1;
    public static final int LED_FRONT_RIGHT = 6;
    public static final int LED_RIGHT = 7;
    
    public static final int SIGNAL_DELTA_THRESHOLD = 500;
    
    protected IRobotCreate create;
    protected EDemoBoard demoBoard;
    protected boolean debugStateMachine;
    protected int state;
    protected int calibratingNotWhiteSignalStrength;
    protected boolean wasOnLeft;
    protected boolean wasOnFrontLeft;
    protected boolean wasOnRight;
    protected boolean keepGoing;
    
    public WhiteLineFollowerUsingSwitchesEventHandler(IRobotCreate create, EDemoBoard demoBoard) {
        this.create = create;
        this.demoBoard = demoBoard;
        keepGoing = true;
    }
    
    
    public void advanceButtonEvent(boolean oldBoolean, boolean advanceButton) {
        super.advanceButtonEvent(oldBoolean, advanceButton);
        create.stop();
        setState(STATE_TEST_WHITELINE);
        create.setCliffSignalHysteresis(25);
    }
    
    public boolean isOnLine(int signalStrength, int ledIndex) {
        boolean isOnLine = Math.abs(calibratingNotWhiteSignalStrength - signalStrength) > SIGNAL_DELTA_THRESHOLD;
        if (debug) {
            System.out.print("signalStrength: ");
            System.out.print(signalStrength);
            System.out.print(" - ");
            System.out.println(isOnLine?"on line":"not on");
        }
        demoBoard.getLEDs()[ledIndex].setRGB(0, 255, 0);
        demoBoard.getLEDs()[ledIndex].setOn(isOnLine);
        return isOnLine;
    }

    public void cliffFrontLeftSignalEvent(int oldInt, int cliffFrontLeftSignal) {
        super.cliffFrontLeftSignalEvent(oldInt, cliffFrontLeftSignal);
        boolean isOnLine = isOnLine(cliffFrontLeftSignal, LED_FRONT_LEFT);
        if (wasOnFrontLeft == isOnLine) {
            return;
        }
        wasOnFrontLeft = isOnLine;
        switch (state) {
        case STATE_CALIBRATING:
            if (isOnLine) {
                create.goForward();
                setState(STATE_GOING_FORWARD);
            }
            break;
        case STATE_ON_LEFT_CLIFF:
        case STATE_ON_RIGHT_CLIFF:
        case STATE_GOING_FORWARD:
        case STATE_TEST_WHITELINE:
            System.out.print("cliffFrontLeftSignal: ");
            System.out.println(cliffFrontLeftSignal);
            break;
        default:
            throw new IllegalStateException("Unknown state");
        }
    }
    
    public void cliffFrontRightSignalEvent(int oldInt, int cliffFrontRightSignal) {
        super.cliffFrontRightSignalEvent(oldInt, cliffFrontRightSignal);
        int signalStrength = create.getCliffFrontRightSignal();
        isOnLine(signalStrength, LED_FRONT_RIGHT);
    }
    
    public void cliffLeftSignalEvent(int oldInt, int cliffLeftSignal) {
        super.cliffLeftSignalEvent(oldInt, cliffLeftSignal);
        boolean isOnLine = isOnLine(cliffLeftSignal, LED_LEFT);
        if (wasOnLeft == isOnLine) {
            return;
        }
        wasOnLeft = isOnLine;
        switch (state) {
        case STATE_CALIBRATING:
            break;
        case STATE_ON_LEFT_CLIFF:
        case STATE_ON_RIGHT_CLIFF:
            if (!isOnLine) {
                create.goForward();
                setState(STATE_GOING_FORWARD);
            }
            break;
        case STATE_GOING_FORWARD:
            setState(STATE_ON_LEFT_CLIFF);
            create.spinLeft();
            break;
        case STATE_TEST_WHITELINE:
            break;
        default:
            throw new IllegalStateException("Unknown state");
        }
    }

    public void cliffRightSignalEvent(int oldInt, int cliffRightSignal) {
        super.cliffRightSignalEvent(oldInt, cliffRightSignal);
        boolean isOnLine = isOnLine(cliffRightSignal, LED_RIGHT);
        if (wasOnRight == isOnLine) {
            return;
        }
        wasOnRight = isOnLine;
        switch (state) {
        case STATE_CALIBRATING:
            break;
        case STATE_ON_LEFT_CLIFF:
        case STATE_ON_RIGHT_CLIFF:
            if (!isOnLine) {
                create.goForward();
                setState(STATE_GOING_FORWARD);
            }
            break;
        case STATE_GOING_FORWARD:
            setState(STATE_ON_RIGHT_CLIFF);
            create.spinRight();
            break;
        case STATE_TEST_WHITELINE:
            break;
        default:
            throw new IllegalStateException("Unknown state");
        }
    }
    
    public void eventBatchEnd() {
        super.eventBatchEnd();
    }

    public void eventBatchStart() {
        super.eventBatchStart();
    }

    public boolean keepGoing() {
        return keepGoing;
    }

    public void bumpLeftEvent(boolean oldBoolean, boolean bumpLeft) {
        super.bumpLeftEvent(oldBoolean, bumpLeft);
        keepGoing = false;
    }

    public void bumpRightEvent(boolean oldBoolean, boolean bumpRight) {
        super.bumpRightEvent(oldBoolean, bumpRight);
        keepGoing = false;
    }

    public void playButtonEvent(boolean oldBoolean, boolean playButton) {
        super.playButtonEvent(oldBoolean, playButton);
        keepGoing = false;
    }
    
    public void pollSensors() {
        create.sensors(IRobotCreateConstants.SENSORS_GROUP_ID6, this);
    }

    protected void setDebugStateMachine(boolean debug) {
        debugStateMachine = debug;
    }

    protected void setState(int state) {
        if (debug || debugStateMachine) {
            String label;
            switch (state) {
            case STATE_CALIBRATING:
                label = "STATE_CALIBRATING";
                break;
            case STATE_ON_LEFT_CLIFF:
                label = "STATE_ON_LEFT_CLIFF";
                break;
            case STATE_ON_RIGHT_CLIFF:
                label = "STATE_ON_RIGHT_CLIFF";
                break;
            case STATE_GOING_FORWARD:
                label = "STATE_GOING_FORWARD";
                break;
            case STATE_TEST_WHITELINE:
                label = "STATE_TEST_WHITELINE";
                break;
            default:
                throw new IllegalStateException("Unknown state");
            }
            System.out.println(label);
        }
        this.state = state;
    }

    public void start() {
        setDebug(true);
        setDebugStateMachine(true);
        setState(STATE_CALIBRATING);
        create.setCliffSignalHysteresis(50);
        create.setDebugCommands(false);
        create.sensors(IRobotCreateConstants.SENSORS_GROUP_ID6, null);
        calibratingNotWhiteSignalStrength = create.getCliffRightSignal();
        if (debug || debugStateMachine) {
            System.out.print("calibratingNotWhiteSignalStrength: ");
            System.out.println(calibratingNotWhiteSignalStrength);
        }
        create.setVelocity(100);
        create.spinRight();
    }

}
