package com.iaroc.irobot.sample;

public class OnRightCliffSensorState extends State {

    public OnRightCliffSensorState(StateMachine machine) {
        super(machine);
    }

    public void cliffFrontRightSignalEvent(int oldInt, int cliffFrontRightSignal) {
        super.cliffFrontLeftSignalEvent(oldInt, cliffFrontRightSignal);
        if (isOnRight) {
            getCreate().spinRight();
        } else {
            getCreate().goForward();
            getStateMachine().enterState(getStateMachine().getGoingForwardState());
        }
    }

}
