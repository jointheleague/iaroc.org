package com.iaroc.irobot.sample;

public class GoingForwardState extends State {

    public GoingForwardState(StateMachine machine) {
        super(machine);
    }

    public void cliffLeftSignalEvent(int oldInt, int cliffFrontLeftSignal) {
        super.cliffLeftSignalEvent(oldInt, cliffFrontLeftSignal);
        if (isOnLeft) {
            getCreate().spinLeft();
            getStateMachine().enterState(getStateMachine().getOnLeftCliffSensorState());
        }
    }

    public void cliffRightSignalEvent(int oldInt, int cliffFrontRightSignal) {
        super.cliffRightSignalEvent(oldInt, cliffFrontRightSignal);
        if (isOnRight) {
            getCreate().spinRight();
            getStateMachine().enterState(getStateMachine().getOnRightCliffSensorState());
        }
    }

}
