package com.iaroc.irobot.sample;

import com.iaroc.irobot.IRobotCreate;
import com.iaroc.irobot.IRobotCreateConstants;

import com.iaroc.irobot.util.XLights;
import com.sun.spot.sensorboard.EDemoBoard;
import com.sun.spot.sensorboard.peripheral.LEDColor;
import com.sun.spot.util.Utils;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/**
 * The startApp method of this class is called by the VM to start the
 * application.
 */
public class BumpsMIDlet extends MIDlet {
    protected IRobotCreate create;
    protected XLights xLights;
    
    protected void doTest() {
        create.leds(true, true, true);
        boolean playLed;
        boolean advanceLed;
        boolean powerLed;
        int runCount = 2;
        playLed = true;
        while (runCount > 0) {
            create.sensors(IRobotCreateConstants.SENSORS_BUMPS_AND_WHEEL_DROPS, null);
            advanceLed = powerLed = true;
            if (create.isBumpLeft() && create.isBumpRight()) {
                playLed = false;
            } else {
                if (!playLed) {
                    runCount--;
                    playLed = true;
                }
                if (create.isBumpLeft()) {
                    powerLed = false;
                } else if (create.isBumpRight()) {
                    advanceLed = false;
                }
            }
            create.leds(powerLed, playLed, advanceLed);
            Utils.sleep(250);
        }
    }

    protected void startApp() throws MIDletStateChangeException {
        xLights = new XLights(EDemoBoard.getInstance(), 0, 7);
        xLights.setColor(LEDColor.WHITE);
        xLights.startPsilon();
        System.out.print("Initializing: ");
        System.out.println(this.getClass().getName());
        xLights.setColor(LEDColor.YELLOW);
        try {
            create = new IRobotCreate();
            // Indicate we have not connected with the Create and are about to execute our test
            xLights.setColor(LEDColor.GREEN);
            // Run the actual test code we want to do
            doTest();
            // Indicate we are done
            xLights.setColor(LEDColor.BLUE);
        } catch (Throwable e) {
            e.printStackTrace();
            // Indicate we got an error
            xLights.setColor(LEDColor.RED);
        }
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
    }
    
}
